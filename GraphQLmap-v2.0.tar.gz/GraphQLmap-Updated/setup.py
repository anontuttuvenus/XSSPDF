#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name='graphqlmap',
    version='2.0',
    description='GraphQLmap v2.0 - Enhanced GraphQL Pentesting Framework',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Original: @pentest_swissky | Enhanced: GraphQLmap Contributors',
    url='https://github.com/swisskyrepo/GraphQLmap',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        '': ['wordlists/*.txt'],
    },
    scripts=['bin/graphqlmap'],
    install_requires=[
        'requests',
    ],
    extras_require={
        'websocket': ['websocket-client'],
        'full': ['websocket-client'],
    },
    python_requires='>=3.7',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Topic :: Security',
    ],
)
