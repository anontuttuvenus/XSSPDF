"""
GraphQLmap v2.0 - GraphQL Pentesting Framework
Enhanced version with modern attack vectors and bypass techniques.
"""

__version__ = "2.0"
__author__ = "Original: @pentest_swissky | Updated: GraphQLmap Contributors"
