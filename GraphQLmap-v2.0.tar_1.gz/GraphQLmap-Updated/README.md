# GraphQLmap v2.0 — Enhanced GraphQL Pentesting Framework

> An enhanced scripting engine to interact with GraphQL endpoints for penetration testing. This is a modernized fork of the original [GraphQLmap](https://github.com/swisskyrepo/GraphQLmap) by @pentest_swissky, updated with the latest attack vectors, bypass techniques, and comprehensive payload libraries as of 2025/2026.

---

## Is This Tool Completely Offline?

**No.** GraphQLmap is **not** an offline tool. It is a network-based pentesting framework that requires an active HTTP connection to a target GraphQL endpoint. Every feature — from schema introspection to injection testing — sends live HTTP requests to the remote server. The tool itself has no local GraphQL engine, no offline schema parser, and no local database. It is designed exclusively for interacting with remote (or locally hosted) GraphQL APIs over the network.

The only "offline" components are the built-in payload lists and wordlists, which are bundled in the repository and do not require internet access to load.

---

## What's New in v2.0 (vs. Original v1.1)

The original GraphQLmap (last updated March 2023) had a limited feature set. This v2.0 update adds **16 major new capabilities** based on research from PortSwigger, PayloadsAllTheThings, AFINE, Checkmarx, and real-world bug bounty findings through 2025/2026.

| Category | Original v1.1 | New in v2.0 |
|---|---|---|
| **Reconnaissance** | None | Endpoint auto-discovery (23 paths), server fingerprinting (16 engines), feature detection |
| **Introspection** | 2 methods (fragment, IntrospectionQuery) | + GET bypass, urlencoded bypass, 12 bypass techniques (newline, tab, comment, alias, fragment-on-Query, whitespace obfuscation) |
| **Schema Recovery** | None when introspection disabled | Field suggestion brute-force (Clairvoyance-style) with 359-word built-in wordlist |
| **Alias Attacks** | None | Alias-based brute force (login/2FA/OTP bypass), alias overloading DoS |
| **Directive Attacks** | None | Directive overloading DoS testing |
| **Depth/Complexity** | None | Nested query depth DoS testing |
| **CSRF** | None | Auto-generates GET, form-POST, and fetch-based CSRF PoC HTML files |
| **SSRF** | None | 21 SSRF payloads (AWS/GCP/Azure metadata, internal services, gopher, file://) |
| **WebSocket** | None | Subscription testing, unauthenticated connection check, CSWSH detection |
| **SQL Injection** | PostgreSQL, MySQL, MSSQL | + Oracle, SQLite, expanded payloads (time-based, union-based, error-based) |
| **NoSQL Injection** | Basic blind | + 14 enhanced payloads ($regex, $ne, $where, $exists, $or, etc.) |
| **Data Extraction** | Basic query | + Relay edges/nodes pagination, cursor-based pagination |
| **Schema Export** | None | Save full + simplified schema to JSON files |
| **Server Fingerprint** | None | Detects 16 engines: Apollo, Hasura, Graphene, Yoga, Ariadne, Strawberry, WPGraphQL, AWS AppSync, Dgraph, HotChocolate, Juniper, Sangria, graphql-ruby, graphql-java, Mercurius, Absinthe |
| **Type Inspection** | Basic `__schema` | + `__type` deep inspection with field details |
| **CLI** | Basic | + `--detect`, `--wordlist`, `--timeout`, `--output` flags |

---

## Installation

```bash
git clone <this-repo>
cd GraphQLmap-Updated
pip install -r requirements.txt
python3 bin/graphqlmap -u https://target.com/graphql
```

For WebSocket subscription testing (optional):
```bash
pip install websocket-client
```

---

## Usage

```
graphqlmap -u <TARGET_URL> [OPTIONS]

Options:
  -u URL              Target GraphQL endpoint URL
  -v                  Enable verbose output
  --method METHOD     HTTP method: GET or POST (default: POST)
  --headers HEADERS   Custom HTTP headers as JSON string
  --json              Force JSON Content-Type
  --proxy PROXY       HTTP proxy (e.g., http://127.0.0.1:8080)
  --output FILE       Save output to file
  --detect            Auto-detect GraphQL endpoint paths
  --wordlist FILE     Custom wordlist for field suggestion brute-force
  --timeout SECONDS   Request timeout (default: 30)
```

### Examples

```bash
# Basic connection
graphqlmap -u https://target.com/graphql

# With authentication
graphqlmap -u https://target.com/graphql --headers '{"Authorization":"Bearer eyJ..."}'

# Through Burp proxy
graphqlmap -u https://target.com/graphql --proxy http://127.0.0.1:8080

# Auto-detect endpoint
graphqlmap -u https://target.com --detect

# Use custom wordlist for field brute-force
graphqlmap -u https://target.com/graphql --wordlist /path/to/wordlist.txt
```

---

## Command Reference

### Reconnaissance

| Command | Description |
|---|---|
| `detect_endpoint` | Scans 23 common GraphQL paths with universal `query{__typename}` probe |
| `fingerprint` | Identifies the GraphQL server engine and checks feature support (introspection, batching, suggestions, GET method) |
| `debug` | Displays all types via `__schema` |

### Schema Dumping & Bypass

| Command | Description |
|---|---|
| `dump_via_introspection` | Full IntrospectionQuery (GraphQL v15+) |
| `dump_via_fragment` | Fragment-based introspection (GraphQL v14) |
| `dump_via_get` | Introspection via GET request (bypasses POST-only WAF rules) |
| `dump_via_urlencoded` | Introspection via `x-www-form-urlencoded` POST (bypasses JSON-only filters) |
| `introspection_bypass` | Tries 12 bypass techniques: newline injection, tab injection, comment injection, aliasing, `__type` probe, operation naming, fragment-on-Query, whitespace obfuscation, GET fallback, urlencoded fallback |
| `field_suggestion` | Clairvoyance-style schema recovery — sends misspelled field names and parses "Did you mean X?" responses to reconstruct the schema when introspection is disabled |
| `type_info <TypeName>` | Deep inspection of a specific type via `__type` query |
| `save_schema` | Exports full and simplified schema to JSON files |

### Injection Attacks

| Command | Description |
|---|---|
| `nosqli` | Blind NoSQL injection with character-by-character extraction using `$regex` |
| `postgresqli` | Blind PostgreSQL injection (12 payloads: `pg_sleep`, UNION, ORDER BY) |
| `mysqli` | Blind MySQL injection (11 payloads: `SLEEP`, `BENCHMARK`, UNION) |
| `mssqli` | Blind MSSQL injection (8 payloads: `WAITFOR DELAY`, UNION) |
| `oraclesqli` | Blind Oracle injection (6 payloads: `DBMS_PIPE`, `UTL_INADDR`, UNION) |
| `sqlitei` | Blind SQLite injection (6 payloads: `randomblob`, UNION) |
| `ssrf_test` | Tests 21 SSRF payloads through URL-accepting GraphQL fields (AWS/GCP/Azure metadata, internal ports, `file://`, `gopher://`) |

### Batching & Brute Force

| Command | Description |
|---|---|
| `BATCHING_N <query>` | Sends N copies of a query in a JSON array batch (rate limit bypass) |
| `alias_bruteforce` | Interactive alias-based brute force — sends multiple aliased mutations in one request to bypass rate limiting. Supports password brute-force, 2FA bypass, OTP bypass. Accepts values from stdin or file. |
| `alias_dos` | Tests alias overloading DoS by sending 1→1000 aliased `__typename` queries and measuring response time degradation |
| `directive_dos` | Tests directive overloading DoS by stacking 1→500 `@skip(if: false)` directives |

### Denial of Service Testing

| Command | Description |
|---|---|
| `depth_dos` | Generates deeply nested circular queries (depth 5→100) to test for missing depth limits |
| `alias_dos` | Alias overloading (see above) |
| `directive_dos` | Directive overloading (see above) |

### CSRF & WebSocket

| Command | Description |
|---|---|
| `csrf_poc` | Auto-detects accepted methods (GET, urlencoded POST) and generates ready-to-use CSRF PoC HTML files (GET-based `<img>` tag, form-based auto-submit, fetch-based JSON) |
| `websocket_test` | Tests GraphQL over WebSocket: unauthenticated connection, introspection over WS, subscription abuse, CSWSH (Cross-Site WebSocket Hijacking) with multiple evil origins |

### Data Extraction

| Command | Description |
|---|---|
| `edges_extract` | Extracts data using Relay-style `edges { node { ... } }` pagination with cursor support |
| `{any GraphQL query}` | Execute any raw query directly |
| `GRAPHQL_CHARSET` | Character brute-force placeholder in queries |
| `GRAPHQL_INCREMENT_N` | Number iteration 0..N placeholder in queries |

---

## Attack Methodology (Recommended Flow)

```
1. detect_endpoint          → Find the GraphQL endpoint
2. fingerprint              → Identify server engine & features
3. dump_via_introspection   → Try standard introspection
4. introspection_bypass     → If blocked, try 12 bypass methods
5. field_suggestion         → If all introspection fails, brute-force fields
6. type_info <Type>         → Deep-dive into interesting types
7. edges_extract            → Extract data with pagination
8. alias_bruteforce         → Test rate limiting / auth bypass
9. nosqli / postgresqli     → Test injection points
10. ssrf_test               → Test SSRF through URL fields
11. csrf_poc                → Generate CSRF proof-of-concept
12. depth_dos / alias_dos   → Test DoS protections
13. websocket_test          → Test WebSocket subscriptions
14. save_schema             → Export findings
```

---

## Built-in Payload Counts

| Category | Count |
|---|---|
| GraphQL endpoint paths | 23 |
| Introspection bypass techniques | 12 |
| Server fingerprint signatures | 16 engines |
| Field suggestion wordlist | 359 words |
| PostgreSQL injection payloads | 12 |
| MySQL injection payloads | 11 |
| MSSQL injection payloads | 8 |
| Oracle injection payloads | 6 |
| SQLite injection payloads | 6 |
| NoSQL injection payloads | 14 |
| SSRF payloads | 21 |
| **Total built-in payloads** | **~170+** |

---

## Comparison: Original vs. Updated

| Feature | Original (v1.1, 2023) | Updated (v2.0, 2026) |
|---|---|---|
| Lines of code | ~450 | ~2,125 |
| Commands | ~10 | ~30+ |
| SQL injection DBs | 3 (PostgreSQL, MySQL, MSSQL) | 5 (+Oracle, SQLite) |
| Introspection methods | 2 | 14 (2 original + 12 bypass) |
| Reconnaissance | None | Endpoint discovery + fingerprinting |
| Schema recovery (no introspection) | None | Field suggestion brute-force |
| Alias attacks | None | Brute force + DoS |
| CSRF | None | Auto PoC generation |
| SSRF | None | 21 payloads |
| WebSocket | None | Full subscription + CSWSH testing |
| DoS testing | None | Depth + Alias + Directive |
| Schema export | None | JSON export |

---

## References

- [PayloadsAllTheThings - GraphQL Injection](https://swisskyrepo.github.io/PayloadsAllTheThings/GraphQL%20Injection/) (same author)
- [PortSwigger - GraphQL API Vulnerabilities](https://portswigger.net/web-security/graphql)
- [AFINE - GraphQL Security from a Pentester's Perspective](https://afine.com/graphql-security-from-a-pentesters-perspective/) (2025)
- [Checkmarx - Alias and Directive Overloading in GraphQL](https://checkmarx.com/blog/alias-and-directive-overloading-in-graphql/)
- [Escape.tech - GraphQL Security Wordlist](https://escape.tech/blog/graphql-security-wordlist/)
- [Clairvoyance - Schema Recovery Tool](https://github.com/nikitastupin/clairvoyance)
- [Intigriti - Five Easy Ways to Hack GraphQL](https://www.intigriti.com/researchers/blog/hacking-tools/five-easy-ways-to-hack-graphql-targets) (2024)

---

## License

MIT License — Same as the original GraphQLmap.

## Disclaimer

This tool is intended for authorized security testing and educational purposes only. Unauthorized access to computer systems is illegal. Always obtain proper authorization before testing.
